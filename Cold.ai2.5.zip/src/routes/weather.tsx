import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import { fetchWeather } from "@/lib/weather/server";

export const Route = createFileRoute("/weather")({ component: WeatherPage });

function WeatherPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const weather = useColdStore((s) => s.weather);
  const online = useColdStore((s) => s.online);
  const [place, setPlace] = useState("");
  const [error, setError] = useState("");

  const load = async () => {
    setError("");
    if (!online) {
      setError(t(loc, "noNetworkWeather"));
      return;
    }
    try {
      const geo = await new Promise<{ lat: number; lon: number } | null>((resolve) => {
        if (!place && navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (p) => resolve({ lat: p.coords.latitude, lon: p.coords.longitude }),
            () => resolve(null),
            { timeout: 4000 },
          );
        } else resolve(null);
      });
      const wx = await fetchWeather({
        data: { locale: loc, place: place || undefined, lat: geo?.lat, lon: geo?.lon },
      });
      if (!wx.ok) {
        setError(t(loc, "noNetworkWeather"));
        return;
      }
      useColdStore.setState({
        weather: {
          summary: wx.summary,
          place: wx.place,
          temp: wx.temp,
          humidity: wx.humidity,
          wind: wx.wind,
          daily: wx.daily,
          at: Date.now(),
        },
      });
    } catch {
      setError(t(loc, "noNetworkWeather"));
    }
  };

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "weatherTitle")} />
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void load();
        }}
      >
        <Input value={place} onChange={(e) => setPlace(e.target.value)} placeholder="Kyiv" />
        <Button type="submit">{t(loc, "search")}</Button>
      </form>
      {error ? <p className="text-sm text-destructive">{error}</p> : null}
      {weather ? (
        <section className="rounded-2xl border border-border bg-card p-6">
          <p className="text-sm text-muted-foreground">{weather.place}</p>
          <p className="font-display text-5xl tracking-tight">{Math.round(weather.temp)}°</p>
          <p className="mt-2 text-sm leading-relaxed">{weather.summary}</p>
          <ul className="mt-6 grid gap-2 sm:grid-cols-3">
            {weather.daily.map((d) => (
              <li key={d.day} className="rounded-xl bg-secondary px-3 py-3 text-sm">
                <p className="text-muted-foreground">{d.day}</p>
                <p className="tabular-nums">
                  {Math.round(d.max)}° / {Math.round(d.min)}°
                </p>
              </li>
            ))}
          </ul>
        </section>
      ) : (
        <p className="text-sm text-muted-foreground">{t(loc, "noNetworkWeather")}</p>
      )}
    </main>
  );
}
