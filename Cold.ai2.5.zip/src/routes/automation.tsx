import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { EmptyState } from "@/components/cold/empty-state";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { uid } from "@/core/id";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import type { PlannedAction } from "@/core/types";

export const Route = createFileRoute("/automation")({ component: AutomationPage });

function AutomationPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const routines = useColdStore((s) => s.routines);
  const automations = useColdStore((s) => s.automations);
  const custom = useColdStore((s) => s.customCommands);
  const runRoutine = useColdStore((s) => s.runRoutine);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "catAutomation")} lead={t(loc, "centerLead")} />
      <Tabs defaultValue="routines">
        <TabsList>
          <TabsTrigger value="routines">{t(loc, "routines")}</TabsTrigger>
          <TabsTrigger value="auto">{t(loc, "automations")}</TabsTrigger>
          <TabsTrigger value="cmd">{t(loc, "customCommands")}</TabsTrigger>
        </TabsList>
        <TabsContent value="routines" className="mt-4 space-y-2">
          {routines.map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <div>
                <p className="text-sm font-medium">{r.name}</p>
                <p className="text-xs text-muted-foreground">{r.description}</p>
              </div>
              <Button size="sm" onClick={() => void runRoutine(r.key)}>
                {t(loc, "run")}
              </Button>
            </div>
          ))}
        </TabsContent>
        <TabsContent value="auto" className="mt-4 space-y-3">
          <NewAutomation />
          {!automations.length ? (
            <EmptyState title={t(loc, "emptyAutomations")} />
          ) : (
            automations.map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3">
                <div>
                  <p className="text-sm font-medium">{a.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {a.trigger.type} · {a.runCount}
                  </p>
                </div>
                <Switch checked={a.enabled} onCheckedChange={() => useColdStore.getState().toggleAutomation(a.id)} />
              </div>
            ))
          )}
        </TabsContent>
        <TabsContent value="cmd" className="mt-4 space-y-3">
          <NewCommand />
          {custom.map((c) => (
            <div key={c.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3">
              <div>
                <p className="text-sm font-medium">{c.phrase}</p>
                <p className="text-xs text-muted-foreground">{c.description}</p>
              </div>
              <Switch checked={c.enabled} onCheckedChange={() => useColdStore.getState().toggleCustomCommand(c.id)} />
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </main>
  );
}

function NewCommand() {
  const loc = useColdStore((s) => s.settings.locale);
  const [phrase, setPhrase] = useState("");
  const add = useColdStore((s) => s.addCustomCommand);
  return (
    <form
      className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4 sm:flex-row"
      onSubmit={(e) => {
        e.preventDefault();
        if (!phrase.trim()) return;
        const actions: PlannedAction[] = [
          { id: uid("act"), kind: "focus_mode", label: "Focus", args: { on: true } },
          { id: uid("act"), kind: "volume_set", label: "Volume 30%", args: { percent: 30 } },
          { id: uid("act"), kind: "event_list", label: "Calendar", args: { range: "today" } },
        ];
        add({ phrase: phrase.trim(), description: "Focus + volume + calendar", actions, enabled: true });
        setPhrase("");
      }}
    >
      <Input value={phrase} onChange={(e) => setPhrase(e.target.value)} placeholder={t(loc, "addCommand")} />
      <Button type="submit">{t(loc, "create")}</Button>
    </form>
  );
}

function NewAutomation() {
  const loc = useColdStore((s) => s.settings.locale);
  const [name, setName] = useState("");
  const [hour, setHour] = useState("8");
  const [minute, setMinute] = useState("00");
  const add = useColdStore((s) => s.addAutomation);
  return (
    <form
      className="grid gap-2 rounded-xl border border-border bg-card p-4 sm:grid-cols-[1fr_5rem_5rem_auto]"
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) return;
        add({
          name: name.trim(),
          enabled: true,
          trigger: { type: "schedule", hour: Number(hour), minute: Number(minute), days: [1, 2, 3, 4, 5] },
          actions: [
            { id: uid("act"), kind: "weather", label: "Weather", args: {} },
            { id: uid("act"), kind: "event_list", label: "Today", args: { range: "today" } },
          ],
        });
        setName("");
      }}
    >
      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t(loc, "addAutomation")} />
      <Input value={hour} onChange={(e) => setHour(e.target.value)} aria-label="hour" />
      <Input value={minute} onChange={(e) => setMinute(e.target.value)} aria-label="minute" />
      <Button type="submit">{t(loc, "create")}</Button>
    </form>
  );
}
