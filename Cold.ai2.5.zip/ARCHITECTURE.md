# Architecture

```
UI ──► Orchestrator
         ├─ Custom commands / automations
         ├─ Intent engine (offline, multilingual)
         ├─ Context engine (last app, last timer, last place)
         ├─ AI provider (xAI, optional)
         ├─ Task planner
         └─ Task executor
              ├─ Apps / Web / Maps / YouTube
              ├─ Calendar / Reminders / Alarms / Timers
              ├─ Memory / Contacts / Files / Gallery
              ├─ Media / Volume (in-app) / Focus mode
              ├─ Weather / Translate / Calculator
              └─ Diagnostics / Notifications
```

## Orchestrator kinds

`local_action` · `task_plan` · `web_task` · `system_task` · `automation` · `memory` · `conversation` · `clarification`

High-confidence local parses never guess missing times, contacts, or delete targets.

## Persistence

Local only (`localStorage`). Export/clear from Settings. Memory is never sent to a server unless you invoke AI and the turn includes a short memory summary you already stored.

## Task states

QUEUED, PLANNING, WAITING_PERMISSION, WAITING_INPUT, WAITING_CONFIRMATION, EXECUTING, VERIFYING, SUCCESS, FAILED, CANCELLED, PAUSED.
