import { create } from "zustand";
import { persist } from "zustand/middleware";
import { defaultRoutines } from "../engines/automation/defaults.ts";
import { parseIntent, questionKeyToPrompt } from "../engines/intent/engine.ts";
import { executeAction, notify } from "../engines/executor/engine.ts";
import { planTask } from "../engines/planner/engine.ts";
import { summarizeMemory } from "../engines/memory/engine.ts";
import { assistTurn } from "@/lib/ai/server";
import { fetchWeather } from "@/lib/weather/server";
import { APP_CATALOG } from "../engines/apps/catalog.ts";
import { logger } from "./logger.ts";
import { t } from "./i18n.ts";
import { uid } from "./id.ts";
import { formatDuration, nextAlarmAt } from "./datetime.ts";
import { normalize } from "./normalize.ts";
import type {
  Alarm,
  AnalyticsSnapshot,
  AppNotification,
  AssistantState,
  Automation,
  CalendarEvent,
  ChatMessage,
  ColdSettings,
  ColdTask,
  ConfirmationRequest,
  Contact,
  ConversationContext,
  CustomCommand,
  HistoryEntry,
  IndexedFile,
  Locale,
  MemoryItem,
  PermissionId,
  PermissionRequest,
  PlannedAction,
  Reminder,
  Routine,
  StopwatchState,
  TimerItem,
  VoiceSettings,
  AiSettings,
} from "./types.ts";

export const APP_VERSION = "1.0.0";

const emptyAnalytics = (): AnalyticsSnapshot => ({
  commands: 0,
  success: 0,
  errors: 0,
  automations: 0,
  byKind: {},
});

type WeatherCache = {
  summary: string;
  place: string;
  temp: number;
  humidity: number;
  wind: number;
  daily: { day: string; max: number; min: number; code: number }[];
  at: number;
} | null;

export interface ColdState {
  settings: ColdSettings;
  voice: VoiceSettings;
  ai: AiSettings;
  assistant: AssistantState;
  online: boolean;
  transcript: string;
  lastCommand: string;
  lastReply: string;
  messages: ChatMessage[];
  context: ConversationContext;
  tasks: ColdTask[];
  activeTaskId: string | null;
  memory: MemoryItem[];
  contacts: Contact[];
  events: CalendarEvent[];
  reminders: Reminder[];
  alarms: Alarm[];
  timers: TimerItem[];
  stopwatch: StopwatchState;
  files: IndexedFile[];
  notifications: AppNotification[];
  automations: Automation[];
  routines: Routine[];
  customCommands: CustomCommand[];
  history: HistoryEntry[];
  analytics: AnalyticsSnapshot;
  confirmation: ConfirmationRequest | null;
  permissionPrompt: PermissionRequest | null;
  mediaVolume: number;
  focusMode: boolean;
  flashlightOn: boolean;
  cameraOpen: boolean;
  pendingNavigate: string | null;
  weather: WeatherCache;
  hydrated: boolean;
  setHydrated: () => void;
  setOnline: (v: boolean) => void;
  setTranscript: (v: string) => void;
  setAssistant: (v: AssistantState) => void;
  patchSettings: (p: Partial<ColdSettings>) => void;
  patchVoice: (p: Partial<VoiceSettings>) => void;
  patchAi: (p: Partial<AiSettings>) => void;
  runTurn: (text: string) => Promise<void>;
  confirmPending: () => Promise<void>;
  cancelPending: () => void;
  tick: () => void;
  addContact: (c: Omit<Contact, "id">) => void;
  removeContact: (id: string) => void;
  addEvent: (e: Omit<CalendarEvent, "id">) => void;
  removeEvent: (id: string) => void;
  addReminder: (title: string, at: number) => void;
  toggleReminder: (id: string) => void;
  addAlarm: (hour: number, minute: number, label?: string) => void;
  toggleAlarm: (id: string) => void;
  addTimer: (durationMs: number, label?: string) => void;
  toggleTimer: (id: string) => void;
  removeTimer: (id: string) => void;
  resetStopwatch: () => void;
  toggleStopwatch: () => void;
  addFiles: (files: IndexedFile[]) => void;
  removeFile: (id: string) => void;
  markNotification: (id: string) => void;
  addCustomCommand: (cmd: Omit<CustomCommand, "id">) => void;
  removeCustomCommand: (id: string) => void;
  toggleCustomCommand: (id: string) => void;
  addAutomation: (a: Omit<Automation, "id" | "runCount">) => void;
  toggleAutomation: (id: string) => void;
  runRoutine: (key: string) => Promise<void>;
  updateRoutine: (id: string, actions: PlannedAction[]) => void;
  clearMemory: () => void;
  exportData: () => string;
  importData: (raw: string) => void;
  clearConfirmation: () => void;
  consumeNavigate: () => string | null;
}

function historyPush(
  list: HistoryEntry[],
  entry: Omit<HistoryEntry, "id" | "at"> & { at?: number },
): HistoryEntry[] {
  return [{ id: uid("his"), at: entry.at ?? Date.now(), ...entry }, ...list].slice(0, 400);
}

function bumpAnalytics(a: AnalyticsSnapshot, kind: string, ok: boolean): AnalyticsSnapshot {
  return {
    commands: a.commands + 1,
    success: a.success + (ok ? 1 : 0),
    errors: a.errors + (ok ? 0 : 1),
    automations: a.automations,
    byKind: { ...a.byKind, [kind]: (a.byKind[kind] ?? 0) + 1 },
  };
}

export const useColdStore = create<ColdState>()(
  persist(
    (set, get) => ({
      settings: {
        locale: "uk",
        theme: "system",
        reducedMotion: false,
        largeText: false,
        confirmSensitive: true,
        offlinePreferLocal: true,
        performanceMode: false,
        showDiagnosticsOnHome: true,
      },
      voice: {
        locale: "uk",
        autoListen: false,
        wakeWord: false,
        wakePhrase: "Cold",
        ttsEnabled: true,
        neuralTts: false,
        rate: 1,
        pitch: 1,
        volume: 1,
      },
      ai: { provider: "xai", model: "grok-4.5", useForLocalCommands: false, maxHistory: 12 },
      assistant: "idle",
      online: typeof navigator === "undefined" ? true : navigator.onLine,
      transcript: "",
      lastCommand: "",
      lastReply: "",
      messages: [],
      context: { entities: [] },
      tasks: [],
      activeTaskId: null,
      memory: [],
      contacts: [],
      events: [],
      reminders: [],
      alarms: [],
      timers: [],
      stopwatch: { running: false, elapsedMs: 0 },
      files: [],
      notifications: [],
      automations: [],
      routines: defaultRoutines(),
      customCommands: [],
      history: [],
      analytics: emptyAnalytics(),
      confirmation: null,
      permissionPrompt: null,
      mediaVolume: 0.7,
      focusMode: false,
      flashlightOn: false,
      cameraOpen: false,
      pendingNavigate: null,
      weather: null,
      hydrated: false,
      setHydrated: () => set({ hydrated: true }),
      setOnline: (v) => set({ online: v }),
      setTranscript: (v) => set({ transcript: v }),
      setAssistant: (v) => set({ assistant: v }),
      patchSettings: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      patchVoice: (p) => set((s) => ({ voice: { ...s.voice, ...p } })),
      patchAi: (p) => set((s) => ({ ai: { ...s.ai, ...p } })),
      consumeNavigate: () => {
        const n = get().pendingNavigate;
        if (n) set({ pendingNavigate: null });
        return n;
      },
      clearConfirmation: () => set({ confirmation: null, permissionPrompt: null }),
      addContact: (c) => set((s) => ({ contacts: [{ id: uid("ct"), ...c }, ...s.contacts] })),
      removeContact: (id) => set((s) => ({ contacts: s.contacts.filter((c) => c.id !== id) })),
      addEvent: (e) => set((s) => ({ events: [{ id: uid("evt"), ...e }, ...s.events] })),
      removeEvent: (id) => set((s) => ({ events: s.events.filter((e) => e.id !== id) })),
      addReminder: (title, at) =>
        set((s) => ({ reminders: [{ id: uid("rem"), title, at, done: false, fired: false }, ...s.reminders] })),
      toggleReminder: (id) =>
        set((s) => ({ reminders: s.reminders.map((r) => (r.id === id ? { ...r, done: !r.done } : r)) })),
      addAlarm: (hour, minute, label) =>
        set((s) => ({
          alarms: [
            {
              id: uid("alm"),
              hour,
              minute,
              label: label ?? `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
              enabled: true,
              days: [],
              nextAt: nextAlarmAt(hour, minute),
            },
            ...s.alarms,
          ],
        })),
      toggleAlarm: (id) =>
        set((s) => ({ alarms: s.alarms.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a)) })),
      addTimer: (durationMs, label) =>
        set((s) => ({
          timers: [
            {
              id: uid("tmr"),
              label: label ?? formatDuration(durationMs),
              durationMs,
              remainingMs: durationMs,
              running: true,
              createdAt: Date.now(),
              endsAt: Date.now() + durationMs,
            },
            ...s.timers,
          ],
        })),
      toggleTimer: (id) =>
        set((s) => ({
          timers: s.timers.map((tm) =>
            tm.id === id
              ? tm.running
                ? { ...tm, running: false, remainingMs: tm.endsAt ? Math.max(0, tm.endsAt - Date.now()) : tm.remainingMs, endsAt: undefined }
                : { ...tm, running: true, endsAt: Date.now() + tm.remainingMs }
              : tm,
          ),
        })),
      removeTimer: (id) => set((s) => ({ timers: s.timers.filter((t0) => t0.id !== id) })),
      resetStopwatch: () => set({ stopwatch: { running: false, elapsedMs: 0 } }),
      toggleStopwatch: () =>
        set((s) =>
          s.stopwatch.running
            ? {
                stopwatch: {
                  running: false,
                  elapsedMs: s.stopwatch.elapsedMs + (Date.now() - (s.stopwatch.startedAt ?? Date.now())),
                },
              }
            : { stopwatch: { running: true, elapsedMs: s.stopwatch.elapsedMs, startedAt: Date.now() } },
        ),
      addFiles: (files) => set((s) => ({ files: [...files, ...s.files] })),
      removeFile: (id) => set((s) => ({ files: s.files.filter((f) => f.id !== id) })),
      markNotification: (id) =>
        set((s) => ({ notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) })),
      addCustomCommand: (cmd) =>
        set((s) => ({ customCommands: [{ id: uid("cmd"), ...cmd }, ...s.customCommands] })),
      removeCustomCommand: (id) => set((s) => ({ customCommands: s.customCommands.filter((c) => c.id !== id) })),
      toggleCustomCommand: (id) =>
        set((s) => ({
          customCommands: s.customCommands.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c)),
        })),
      addAutomation: (a) =>
        set((s) => ({ automations: [{ id: uid("auto"), runCount: 0, ...a }, ...s.automations] })),
      toggleAutomation: (id) =>
        set((s) => ({ automations: s.automations.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a)) })),
      updateRoutine: (id, actions) =>
        set((s) => ({ routines: s.routines.map((r) => (r.id === id ? { ...r, actions } : r)) })),
      clearMemory: () => set({ memory: [] }),
      exportData: () => {
        const s = get();
        return JSON.stringify(
          {
            memory: s.memory,
            contacts: s.contacts,
            events: s.events,
            reminders: s.reminders,
            alarms: s.alarms,
            customCommands: s.customCommands,
            automations: s.automations,
            routines: s.routines,
            settings: s.settings,
          },
          null,
          2,
        );
      },
      importData: (raw) => {
        try {
          const data = JSON.parse(raw) as Partial<ColdState>;
          set({
            memory: data.memory ?? get().memory,
            contacts: data.contacts ?? get().contacts,
            events: data.events ?? get().events,
            reminders: data.reminders ?? get().reminders,
            alarms: data.alarms ?? get().alarms,
            customCommands: data.customCommands ?? get().customCommands,
            automations: data.automations ?? get().automations,
            routines: data.routines ?? get().routines,
          });
        } catch (err) {
          logger.error("MEMORY", "import failed", { error: String(err) });
        }
      },
      cancelPending: () => {
        const s = get();
        const loc = s.settings.locale;
        set({
          confirmation: null,
          permissionPrompt: null,
          assistant: "idle",
          lastReply: t(loc, "cancelled"),
          messages: [
            ...s.messages,
            { id: uid("msg"), role: "assistant", text: t(loc, "cancelled"), at: Date.now() },
          ],
        });
      },
      confirmPending: async () => {
        const s = get();
        const action = s.confirmation?.action;
        set({ confirmation: null });
        if (action) await applyActions([action]);
      },
      runRoutine: async (key) => {
        const routine = get().routines.find((r) => r.key === key || r.id === key);
        if (!routine) return;
        await applyActions(routine.actions, routine.name);
      },
      tick: () => {
        const s = get();
        const now = Date.now();
        let notifications = s.notifications;
        let timers = s.timers.map((tm) => {
          if (!tm.running || !tm.endsAt) return tm;
          const remaining = Math.max(0, tm.endsAt - now);
          return { ...tm, remainingMs: remaining, running: remaining > 0 };
        });
        const finished = s.timers.filter((tm) => tm.running && tm.endsAt && tm.endsAt <= now);
        if (finished.length) {
          for (const tm of finished) {
            notifications = [notify("timer", tm.label, t(s.settings.locale, "success"), true), ...notifications];
            void speakNow(t(s.settings.locale, "success") + " " + tm.label);
            void maybeDesktopNotify(tm.label, t(s.settings.locale, "success"));
          }
        }
        let reminders = s.reminders.map((r) => {
          if (!r.done && !r.fired && r.at <= now) {
            notifications = [notify("reminder", r.title, formatDuration(0), true), ...notifications];
            void speakNow(r.title);
            void maybeDesktopNotify(r.title, t(s.settings.locale, "remindersTitle"));
            return { ...r, fired: true };
          }
          return r;
        });
        let alarms = s.alarms.map((a) => {
          if (a.enabled && a.nextAt <= now && a.firedAt !== a.nextAt) {
            notifications = [notify("alarm", a.label, t(s.settings.locale, "alarmsTitle"), true), ...notifications];
            void speakNow(a.label);
            void maybeDesktopNotify(a.label, t(s.settings.locale, "alarmsTitle"));
            return { ...a, firedAt: a.nextAt, nextAt: nextAlarmAt(a.hour, a.minute, new Date(now + 1000)) };
          }
          return a;
        });
        let stopwatch = s.stopwatch;
        if (stopwatch.running && stopwatch.startedAt) {
          stopwatch = { ...stopwatch, elapsedMs: stopwatch.elapsedMs };
        }
        if (finished.length || reminders !== s.reminders || alarms !== s.alarms || timers !== s.timers) {
          set({ timers, reminders, alarms, notifications: notifications.slice(0, 200) });
        }
        const autos = s.automations.filter((a) => a.enabled && a.trigger.type === "schedule");
        for (const auto of autos) {
          if (auto.trigger.type !== "schedule") continue;
          const d = new Date(now);
          if (d.getHours() === auto.trigger.hour && d.getMinutes() === auto.trigger.minute && d.getSeconds() < 2) {
            if (!auto.lastRunAt || now - auto.lastRunAt > 50_000) {
              set({
                automations: get().automations.map((x) =>
                  x.id === auto.id ? { ...x, lastRunAt: now, runCount: x.runCount + 1 } : x,
                ),
                analytics: { ...get().analytics, automations: get().analytics.automations + 1 },
              });
              void applyActions(auto.actions, auto.name);
            }
          }
        }
      },
      runTurn: async (raw) => {
        const text = raw.trim();
        const s0 = get();
        const loc = s0.settings.locale;
        if (!text) {
          const msg = t(loc, "emptyInput");
          set({ lastReply: msg, assistant: "idle" });
          return;
        }
        logger.info("VOICE", "turn", { text });
        const userMsg: ChatMessage = { id: uid("msg"), role: "user", text, at: Date.now() };
        set({
          assistant: "thinking",
          lastCommand: text,
          transcript: text,
          messages: [...s0.messages, userMsg].slice(-80),
        });

        const n = normalize(text);
        const cmd = s0.customCommands.find((c) => c.enabled && normalize(c.phrase) === n);
        if (cmd) {
          await applyActions(cmd.actions, cmd.phrase);
          return;
        }
        const auto = s0.automations.find(
          (a) => a.enabled && a.trigger.type === "voice" && normalize(a.trigger.phrase) === n,
        );
        if (auto) {
          set({
            automations: get().automations.map((x) =>
              x.id === auto.id ? { ...x, lastRunAt: Date.now(), runCount: x.runCount + 1 } : x,
            ),
            analytics: { ...get().analytics, automations: get().analytics.automations + 1 },
          });
          await applyActions(auto.actions, auto.name);
          return;
        }

        const parsed = parseIntent({
          text,
          locale: loc,
          contacts: s0.contacts,
          apps: APP_CATALOG,
          lastAppId: s0.context.lastAppId,
          lastIntent: s0.context.lastIntent,
          lastDurationMs: s0.context.lastDurationMs,
          lastPlace: s0.context.lastPlace,
        });

        if (parsed.question) {
          const q = questionKeyToPrompt(parsed.question, loc);
          finishReply(q, "clarification", false);
          set({
            assistant: "awaiting",
            context: { ...get().context, pendingQuestion: parsed.question },
          });
          return;
        }

        const needsAi =
          parsed.kind === "conversation" ||
          parsed.actions.some((a) => a.kind === "ai_respond" || a.kind === "translate") ||
          (s0.ai.useForLocalCommands && parsed.confidence < 0.9);

        if (needsAi) {
          if (!get().online) {
            if (parsed.confidence >= 0.82 && parsed.kind !== "conversation") {
              await applyActions(parsed.actions, parsed.planTitle ?? text, parsed);
              return;
            }
            finishReply(t(loc, "noNetworkAi"), "conversation", false);
            return;
          }
          try {
            const mode = parsed.actions[0]?.kind === "translate" ? "translate" : parsed.kind === "conversation" ? "chat" : "orchestrate";
            const res = await assistTurn({
              data: {
                text,
                locale: loc,
                context: JSON.stringify(get().context),
                memory: summarizeMemory(get().memory),
                localHint: `${parsed.kind} ${parsed.confidence}`,
                mode,
                targetLang: String(parsed.actions[0]?.args.target ?? "en"),
              },
            });
            if (!res.ok) {
              if (parsed.confidence >= 0.75) {
                await applyActions(parsed.actions, parsed.planTitle ?? text, parsed);
                return;
              }
              finishReply(res.error, "conversation", false);
              return;
            }
            if (mode === "translate" || mode === "chat") {
              finishReply(res.reply, mode === "translate" ? "web_task" : "conversation", true);
              return;
            }
            const remoteActions = Array.isArray(res.actions)
              ? (res.actions as { kind?: string; label?: string; args?: Record<string, unknown> }[]).map((a) => ({
                  id: uid("act"),
                  kind: (a.kind ?? "none") as PlannedAction["kind"],
                  label: a.label ?? a.kind ?? "action",
                  args: a.args ?? {},
                }))
              : parsed.actions;
            const actions = remoteActions.length ? remoteActions : parsed.actions;
            if (res.question) {
              finishReply(res.reply || String(res.question), "clarification", true);
              set({ assistant: "awaiting" });
              return;
            }
            await applyActions(actions, parsed.planTitle ?? text, parsed, { aiReply: res.reply });
            return;
          } catch (err) {
            logger.error("AI", "assist failed", { error: String(err) });
            if (parsed.confidence >= 0.75) {
              await applyActions(parsed.actions, parsed.planTitle ?? text, parsed);
              return;
            }
            finishReply(t(loc, "noNetworkAi"), "conversation", false);
            return;
          }
        }

        await applyActions(parsed.actions, parsed.planTitle ?? text, parsed);
      },
    }),
    {
      name: "cold-ai-v1",
      partialize: (s) => ({
        settings: s.settings,
        voice: s.voice,
        ai: s.ai,
        messages: s.messages.slice(-40),
        context: s.context,
        memory: s.memory,
        contacts: s.contacts,
        events: s.events,
        reminders: s.reminders,
        alarms: s.alarms,
        timers: s.timers.map((tm) => ({ ...tm, running: false })),
        stopwatch: { running: false, elapsedMs: s.stopwatch.elapsedMs },
        files: s.files,
        notifications: s.notifications.slice(0, 80),
        automations: s.automations,
        routines: s.routines,
        customCommands: s.customCommands,
        history: s.history.slice(0, 200),
        analytics: s.analytics,
        mediaVolume: s.mediaVolume,
        focusMode: s.focusMode,
        lastCommand: s.lastCommand,
        lastReply: s.lastReply,
        weather: s.weather,
      }),
    },
  ),
);

function finishReply(text: string, kind: string, usedAi: boolean, ok = true) {
  const s = useColdStore.getState();
  const msg: ChatMessage = {
    id: uid("msg"),
    role: "assistant",
    text,
    at: Date.now(),
    kind: kind as ChatMessage["kind"],
  };
  useColdStore.setState({
    lastReply: text,
    assistant: s.voice.ttsEnabled ? "speaking" : "idle",
    messages: [...s.messages, msg].slice(-80),
    history: historyPush(s.history, { type: "conversation", title: s.lastCommand, detail: text, ok }),
    analytics: bumpAnalytics(s.analytics, kind, ok),
  });
  void speakNow(text);
  logger.info("AI", "reply", { kind, usedAi });
}

async function applyActions(
  actions: PlannedAction[],
  title?: string,
  parsed?: ReturnType<typeof parseIntent>,
  extras?: { aiReply?: string },
) {
  const s = useColdStore.getState();
  const loc = s.settings.locale;
  if (!actions.length) {
    finishReply(extras?.aiReply || t(loc, "tryAgain"), parsed?.kind ?? "conversation", Boolean(extras?.aiReply));
    return;
  }

  const sensitive = actions.find((a) => a.requiresConfirmation || a.kind === "call" || a.kind === "sms" || a.kind === "file_delete");
  if (sensitive && s.settings.confirmSensitive && !s.confirmation) {
    const body =
      sensitive.kind === "call"
        ? `${t(loc, "confirmCall")} ${String(sensitive.args.name ?? "")}?`
        : sensitive.kind === "sms"
          ? `${t(loc, "confirmSms")} ${String(sensitive.args.text ?? "")}?`
          : t(loc, "confirmDelete");
    useColdStore.setState({
      assistant: "awaiting",
      confirmation: {
        id: uid("cnf"),
        title: sensitive.label,
        body,
        confirmLabel: t(loc, "confirm"),
        cancelLabel: t(loc, "cancel"),
        action: sensitive,
      },
    });
    return;
  }

  const task = planTask(title || actions[0]!.label, s.lastCommand, actions);
  useColdStore.setState({
    tasks: [task, ...s.tasks].slice(0, 50),
    activeTaskId: task.id,
    assistant: "executing",
  });

  const replies: string[] = [];
  let okAll = true;
  const ctx = { lastAppId: s.context.lastAppId, lastIntent: actions[0]?.kind, lastDurationMs: s.context.lastDurationMs, lastPlace: s.context.lastPlace, lastQuery: s.context.lastQuery, entities: s.context.entities, lastContactId: s.context.lastContactId, lastVolume: s.context.lastVolume };

  for (let i = 0; i < actions.length; i++) {
    const action = actions[i]!;
    if (action.kind === "ask_user") {
      const q = questionKeyToPrompt(String(action.args.question ?? ""), loc);
      useColdStore.setState((cur) => ({
        tasks: cur.tasks.map((tk) =>
          tk.id === task.id ? { ...tk, state: "WAITING_INPUT", reply: q } : tk,
        ),
        assistant: "awaiting",
        lastReply: q,
      }));
      finishReply(q, "clarification", false);
      return;
    }
    if (action.kind === "routine_run") {
      const key = String(action.args.routineId ?? "");
      const routine = useColdStore.getState().routines.find((r) => r.key === key || r.id === key);
      if (routine) {
        await applyActions(routine.actions, routine.name);
        return;
      }
    }
    if (action.kind === "weather") {
      const st = useColdStore.getState();
      if (!st.online) {
        markStep(task.id, i, false, t(loc, "noNetworkWeather"));
        okAll = false;
        replies.push(t(loc, "noNetworkWeather"));
        continue;
      }
      try {
        const geo = await getGeo();
        const wx = await fetchWeather({
          data: {
            locale: loc,
            place: action.args.place ? String(action.args.place) : undefined,
            lat: geo?.lat,
            lon: geo?.lon,
          },
        });
        if (wx.ok) {
          useColdStore.setState({
            weather: {
              summary: wx.summary,
              place: wx.place,
              temp: wx.temp,
              humidity: wx.humidity,
              wind: wx.wind,
              daily: wx.daily,
              at: Date.now(),
            },
          });
          const r = executeAction(action, snapshot(), { weatherSummary: wx.summary });
          applyResult(r);
          markStep(task.id, i, r.ok, r.message);
          replies.push(r.message);
          if (r.navigate) useColdStore.setState({ pendingNavigate: r.navigate });
        } else {
          const msg = t(loc, "noNetworkWeather");
          markStep(task.id, i, false, msg);
          okAll = false;
          replies.push(msg);
        }
      } catch (err) {
        logger.error("ERROR", "weather", { error: String(err) });
        okAll = false;
        replies.push(t(loc, "noNetworkWeather"));
      }
      continue;
    }
    if (action.kind === "open_app") ctx.lastAppId = String(action.args.appId ?? ctx.lastAppId);
    if (action.kind === "timer_create") ctx.lastDurationMs = Number(action.args.durationMs ?? ctx.lastDurationMs);
    if (action.kind === "search_maps" || action.kind === "navigate") ctx.lastPlace = String(action.args.query ?? "");
    ctx.lastIntent = action.kind;

    const r = executeAction(action, snapshot(), { aiReply: extras?.aiReply });
    applyResult(r);
    markStep(task.id, i, r.ok, r.message);
    replies.push(r.message);
    if (!r.ok && !action.optional) {
      okAll = false;
      break;
    }
  }

  const reply = extras?.aiReply && actions.every((a) => a.kind === "ai_respond") ? extras.aiReply : replies.filter(Boolean).join(" ");
  useColdStore.setState((cur) => ({
    tasks: cur.tasks.map((tk) =>
      tk.id === task.id ? { ...tk, state: okAll ? "SUCCESS" : "FAILED", reply, updatedAt: Date.now() } : tk,
    ),
    context: { ...cur.context, ...ctx, pendingQuestion: undefined },
    history: historyPush(cur.history, {
      type: "task",
      title: title || cur.lastCommand,
      detail: reply,
      ok: okAll,
    }),
    analytics: bumpAnalytics(cur.analytics, parsed?.kind ?? "task_plan", okAll),
  }));
  finishReply(reply || t(loc, okAll ? "success" : "failed"), parsed?.kind ?? "task_plan", Boolean(extras?.aiReply), okAll);
}

function snapshot() {
  const s = useColdStore.getState();
  return {
    locale: s.settings.locale,
    mediaVolume: s.mediaVolume,
    focusMode: s.focusMode,
    flashlightOn: s.flashlightOn,
    contacts: s.contacts,
    events: s.events,
    reminders: s.reminders,
    alarms: s.alarms,
    timers: s.timers,
    memory: s.memory,
    files: s.files,
    notifications: s.notifications,
    stopwatch: s.stopwatch,
    lastCommand: s.lastCommand,
    history: s.history,
    online: s.online,
  };
}

function applyResult(r: ReturnType<typeof executeAction>) {
  if (r.patch) useColdStore.setState(r.patch as Partial<ColdState>);
  if (r.openUrl && typeof window !== "undefined") window.open(r.openUrl, "_blank", "noopener,noreferrer");
  if (r.navigate) useColdStore.setState({ pendingNavigate: r.navigate });
}

function markStep(taskId: string, index: number, ok: boolean, result: string) {
  useColdStore.setState((s) => ({
    tasks: s.tasks.map((tk) =>
      tk.id !== taskId
        ? tk
        : {
            ...tk,
            state: "EXECUTING",
            steps: tk.steps.map((st, i) =>
              i === index ? { ...st, state: ok ? "SUCCESS" : "FAILED", result, error: ok ? undefined : result } : st,
            ),
          },
    ),
  }));
}

export function speakNow(text: string) {
  if (typeof window === "undefined") return;
  const s = useColdStore.getState();
  if (!s.voice.ttsEnabled || s.focusMode) {
    useColdStore.setState({ assistant: "idle" });
    return;
  }
  window.speechSynthesis?.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = s.voice.rate;
  u.pitch = s.voice.pitch;
  u.volume = s.voice.volume * s.mediaVolume;
  const tag = s.settings.locale === "uk" ? "uk" : s.settings.locale;
  const voice = window.speechSynthesis.getVoices().find((v) => v.lang.toLowerCase().startsWith(tag));
  if (voice) u.voice = voice;
  u.onend = () => {
    const st = useColdStore.getState();
    useColdStore.setState({ assistant: st.voice.autoListen ? "listening" : "idle" });
  };
  u.onerror = () => useColdStore.setState({ assistant: "idle" });
  window.speechSynthesis.speak(u);
}

export function stopSpeaking() {
  if (typeof window === "undefined") return;
  window.speechSynthesis?.cancel();
  useColdStore.setState({ assistant: "idle" });
}

async function maybeDesktopNotify(title: string, body: string) {
  if (typeof window === "undefined" || typeof Notification === "undefined") return;
  if (Notification.permission !== "granted") return;
  try {
    new Notification(title, { body });
  } catch {
    /* ignore */
  }
}

async function getGeo(): Promise<{ lat: number; lon: number } | null> {
  if (typeof navigator === "undefined" || !navigator.geolocation) return null;
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lon: p.coords.longitude }),
      () => resolve(null),
      { timeout: 4000, maximumAge: 600_000 },
    );
  });
}

export const fileBlobs = new Map<string, File>();
export const fileUrls = new Map<string, string>();
