# Automation

## Triggers

- Voice phrase
- Manual run
- Daily schedule (hour/minute)
- App open (planner)
- Online / offline / startup events (executor tick)

## Actions

Launch app, web search, YouTube, maps, timer, alarm, reminder, calendar, volume (COLD media), focus mode, weather, AI reply, custom command chain.

## Routines

Editable defaults: Good morning, Good night, Work, Study, Gaming, Travel, Driving, Focus, Silent, Home, Leaving home.

## Custom commands

Phrase → ordered actions. Example: “режим роботи” → volume 30%, focus, calendar.
