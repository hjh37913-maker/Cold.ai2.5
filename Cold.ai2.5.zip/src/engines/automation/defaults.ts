import { uid } from "../../core/id.ts";
import type { PlannedAction, Routine } from "../../core/types.ts";

function a(kind: PlannedAction["kind"], label: string, args: Record<string, unknown> = {}): PlannedAction {
  return { id: uid("act"), kind, label, args };
}

export function defaultRoutines(): Routine[] {
  return [
    {
      id: "good_morning",
      key: "good_morning",
      name: "Good morning",
      description: "Weather, calendar, and a short briefing.",
      editable: true,
      actions: [
        a("weather", "Weather"),
        a("event_list", "Today", { range: "today" }),
        a("reminder_list", "Reminders"),
      ],
    },
    {
      id: "good_night",
      key: "good_night",
      name: "Good night",
      description: "Lower media volume, focus mode, optional alarm.",
      editable: true,
      actions: [
        a("volume_set", "Volume 10%", { percent: 10 }),
        a("focus_mode", "Focus on", { on: true }),
        a("ask_user", "Alarm?", { question: "alarm_time", optional: true }),
      ],
    },
    {
      id: "work",
      key: "work",
      name: "Work",
      description: "Calendar, notes, volume down.",
      editable: true,
      actions: [
        a("volume_set", "Volume 30%", { percent: 30 }),
        a("event_list", "Today", { range: "today" }),
        a("open_app", "Notes", { appId: "notes" }),
        a("focus_mode", "Focus on", { on: true }),
      ],
    },
    {
      id: "study",
      key: "study",
      name: "Study",
      description: "Silence, timer, focus.",
      editable: true,
      actions: [
        a("focus_mode", "Focus on", { on: true }),
        a("volume_set", "Volume 0%", { percent: 0 }),
        a("timer_create", "45 min", { durationMs: 45 * 60_000, label: "Study" }),
      ],
    },
    {
      id: "gaming",
      key: "gaming",
      name: "Gaming",
      description: "Media volume up, YouTube optional.",
      editable: true,
      actions: [a("volume_set", "Volume 70%", { percent: 70 }), a("focus_mode", "Focus off", { on: false })],
    },
    {
      id: "travel",
      key: "travel",
      name: "Travel",
      description: "Maps and weather.",
      editable: true,
      actions: [a("weather", "Weather"), a("open_app", "Maps", { appId: "maps" })],
    },
    {
      id: "driving",
      key: "driving",
      name: "Driving",
      description: "Maps and larger spoken replies.",
      editable: true,
      actions: [a("open_app", "Maps", { appId: "maps" }), a("volume_set", "Volume 60%", { percent: 60 })],
    },
    {
      id: "focus",
      key: "focus",
      name: "Focus",
      description: "Do-not-disturb substitute and quiet media.",
      editable: true,
      actions: [a("focus_mode", "Focus on", { on: true }), a("volume_set", "Volume 15%", { percent: 15 })],
    },
    {
      id: "silent",
      key: "silent",
      name: "Silent",
      description: "Mute COLD media and enable focus.",
      editable: true,
      actions: [a("volume_set", "Mute", { percent: 0 }), a("focus_mode", "Focus on", { on: true })],
    },
    {
      id: "home",
      key: "home",
      name: "Home",
      description: "Calendar and weather.",
      editable: true,
      actions: [a("weather", "Weather"), a("event_list", "Today", { range: "today" })],
    },
    {
      id: "leaving",
      key: "leaving",
      name: "Leaving home",
      description: "Maps and next event.",
      editable: true,
      actions: [a("event_list", "Today", { range: "today" }), a("open_app", "Maps", { appId: "maps" })],
    },
  ];
}
