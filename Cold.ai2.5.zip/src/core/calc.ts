const UNIT_TO_SI: Record<string, { dim: string; to: number }> = {
  km: { dim: "length", to: 1000 },
  kilometer: { dim: "length", to: 1000 },
  kilometers: { dim: "length", to: 1000 },
  кілометр: { dim: "length", to: 1000 },
  кілометри: { dim: "length", to: 1000 },
  кілометрів: { dim: "length", to: 1000 },
  m: { dim: "length", to: 1 },
  meter: { dim: "length", to: 1 },
  meters: { dim: "length", to: 1 },
  метр: { dim: "length", to: 1 },
  метри: { dim: "length", to: 1 },
  метрів: { dim: "length", to: 1 },
  mi: { dim: "length", to: 1609.344 },
  mile: { dim: "length", to: 1609.344 },
  miles: { dim: "length", to: 1609.344 },
  миля: { dim: "length", to: 1609.344 },
  милі: { dim: "length", to: 1609.344 },
  миль: { dim: "length", to: 1609.344 },
  ft: { dim: "length", to: 0.3048 },
  foot: { dim: "length", to: 0.3048 },
  feet: { dim: "length", to: 0.3048 },
  kg: { dim: "mass", to: 1 },
  kilogram: { dim: "mass", to: 1 },
  kilograms: { dim: "mass", to: 1 },
  кілограм: { dim: "mass", to: 1 },
  кілограми: { dim: "mass", to: 1 },
  кілограмів: { dim: "mass", to: 1 },
  lb: { dim: "mass", to: 0.45359237 },
  lbs: { dim: "mass", to: 0.45359237 },
  pound: { dim: "mass", to: 0.45359237 },
  pounds: { dim: "mass", to: 0.45359237 },
  c: { dim: "temp", to: 1 },
  celsius: { dim: "temp", to: 1 },
  цельсій: { dim: "temp", to: 1 },
  f: { dim: "temp", to: 1 },
  fahrenheit: { dim: "temp", to: 1 },
  фаренгейт: { dim: "temp", to: 1 },
};

function tokenizeExpr(src: string): string[] {
  const out: string[] = [];
  const re = /(\d+(?:[.,]\d+)?)|[+\-*/×÷()%]|[a-zA-Zа-яА-ЯіІїЇєЄґҐ]+/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) out.push(m[0]!.replace(",", "."));
  return out;
}

class Parser {
  constructor(private tokens: string[], private i = 0) {}
  peek() {
    return this.tokens[this.i];
  }
  eat(v?: string) {
    if (v && this.tokens[this.i] !== v) return undefined;
    return this.tokens[this.i++];
  }
  parse(): number {
    const v = this.expr();
    if (this.i < this.tokens.length && this.peek() !== "%") {
      throw new Error("trailing");
    }
    return v;
  }
  expr(): number {
    let v = this.term();
    while (this.peek() === "+" || this.peek() === "-") {
      const op = this.eat();
      const r = this.term();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }
  term(): number {
    let v = this.unary();
    while (this.peek() === "*" || this.peek() === "/" || this.peek() === "×" || this.peek() === "÷") {
      const op = this.eat();
      const r = this.unary();
      v = op === "*" || op === "×" ? v * r : r === 0 ? Number.NaN : v / r;
    }
    return v;
  }
  unary(): number {
    if (this.peek() === "-") {
      this.eat();
      return -this.unary();
    }
    if (this.peek() === "+") {
      this.eat();
      return this.unary();
    }
    return this.primary();
  }
  primary(): number {
    const t = this.peek();
    if (!t) throw new Error("empty");
    if (t === "(") {
      this.eat();
      const v = this.expr();
      if (this.eat(")") === undefined) throw new Error("paren");
      return v;
    }
    if (/^\d/.test(t)) {
      this.eat();
      let n = Number(t);
      if (this.peek() === "%") {
        this.eat();
        n = n / 100;
      }
      return n;
    }
    throw new Error("token");
  }
}

function percentOf(text: string): number | null {
  const m = text.match(/(\d+(?:[.,]\d+)?)\s*%\s*(?:of|від|z|von)\s*(\d+(?:[.,]\d+)?)/i);
  if (!m) return null;
  return (Number(m[1]!.replace(",", ".")) / 100) * Number(m[2]!.replace(",", "."));
}

function convert(text: string): string | null {
  const m = text.match(
    /(\d+(?:[.,]\d+)?)\s*([a-zA-Zа-яА-ЯіІїЇєЄґҐ]+)\s*(?:in|to|у|в|на|do|in)\s*([a-zA-Zа-яА-ЯіІїЇєЄґҐ]+)/i,
  );
  if (!m) return null;
  const value = Number(m[1]!.replace(",", "."));
  const from = UNIT_TO_SI[m[2]!.toLowerCase()];
  const to = UNIT_TO_SI[m[3]!.toLowerCase()];
  if (!from || !to || from.dim !== to.dim) return null;
  if (from.dim === "temp") {
    const fromU = m[2]!.toLowerCase();
    const toU = m[3]!.toLowerCase();
    let c = value;
    if (fromU.startsWith("f") || fromU.includes("фарен")) c = ((value - 32) * 5) / 9;
    let out = c;
    if (toU.startsWith("f") || toU.includes("фарен")) out = (c * 9) / 5 + 32;
    return `${trimNum(out)} ${m[3]}`;
  }
  const si = value * from.to;
  return `${trimNum(si / to.to)} ${m[3]}`;
}

export function trimNum(n: number): string {
  if (!Number.isFinite(n)) return "NaN";
  const r = Math.round(n * 1e6) / 1e6;
  return String(r);
}

export function evaluateMath(raw: string): { ok: true; value: string } | { ok: false; error: string } {
  const text = raw
    .replace(/помнож(ити)? на/gi, "*")
    .replace(/поділ(ити)? на/gi, "/")
    .replace(/плюс/gi, "+")
    .replace(/мінус/gi, "-")
    .replace(/multiply(?:\s+by)?/gi, "*")
    .replace(/times/gi, "*")
    .replace(/divided by/gi, "/")
    .replace(/plus/gi, "+")
    .replace(/minus/gi, "-")
    .replace(/mal/gi, "*")
    .replace(/razy/gi, "*");

  const pct = percentOf(text);
  if (pct !== null) return { ok: true, value: trimNum(pct) };
  const conv = convert(text);
  if (conv) return { ok: true, value: conv };

  const expr = text.replace(/[^\d+\-*/×÷()%.,\s]/g, " ");
  try {
    const tokens = tokenizeExpr(expr);
    if (!tokens.length) return { ok: false, error: "empty" };
    const value = new Parser(tokens).parse();
    if (!Number.isFinite(value)) return { ok: false, error: "invalid" };
    return { ok: true, value: trimNum(value) };
  } catch {
    return { ok: false, error: "parse" };
  }
}

export function looksLikeMath(text: string): boolean {
  if (percentOf(text) !== null) return true;
  if (convert(text) !== null) return true;
  return /(\d+\s*[+\-*/×÷]\s*\d+)|скільки буде|how much is|calculate|policz|berechne/i.test(
    text,
  );
}
