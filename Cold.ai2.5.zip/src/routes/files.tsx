import { createFileRoute, useSearch } from "@tanstack/react-router";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { uid } from "@/core/id";
import { t } from "@/core/i18n";
import { fileBlobs, fileUrls, useColdStore } from "@/core/store";
import type { IndexedFile } from "@/core/types";

export const Route = createFileRoute("/files")({
  validateSearch: (s: Record<string, unknown>) => ({ tab: typeof s.tab === "string" ? s.tab : "files" }),
  component: FilesPage,
});

function kindOf(file: File): IndexedFile["kind"] {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("audio/")) return "audio";
  if (file.type.startsWith("video/")) return "video";
  if (/pdf|text|document|sheet/.test(file.type)) return "document";
  return "other";
}

function FilesPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const files = useColdStore((s) => s.files);
  const addFiles = useColdStore((s) => s.addFiles);
  const removeFile = useColdStore((s) => s.removeFile);
  const search = useSearch({ from: "/files" });
  const images = files.filter((f) => f.kind === "image");

  const onPick = (list: FileList | null) => {
    if (!list?.length) return;
    const rows: IndexedFile[] = [];
    for (const file of Array.from(list)) {
      const id = uid("file");
      fileBlobs.set(id, file);
      fileUrls.set(id, URL.createObjectURL(file));
      rows.push({
        id,
        name: file.name,
        type: file.type,
        size: file.size,
        addedAt: Date.now(),
        kind: kindOf(file),
      });
    }
    addFiles(rows);
  };

  const open = (id: string) => {
    const url = fileUrls.get(id);
    if (url) window.open(url, "_blank", "noopener");
  };

  const share = async (id: string) => {
    const file = fileBlobs.get(id);
    if (file && navigator.share) {
      try {
        await navigator.share({ files: [file], title: file.name });
      } catch {
        /* cancelled */
      }
    }
  };

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader
        title={t(loc, "filesTitle")}
        actions={
          <label className="inline-flex h-11 cursor-pointer items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground">
            {t(loc, "create")}
            <input
              type="file"
              multiple
              className="sr-only"
              onChange={(e) => onPick(e.target.files)}
            />
          </label>
        }
      />
      <Tabs defaultValue={search.tab === "gallery" ? "gallery" : "files"}>
        <TabsList>
          <TabsTrigger value="files">{t(loc, "filesTitle")}</TabsTrigger>
          <TabsTrigger value="gallery">{t(loc, "galleryTitle")}</TabsTrigger>
        </TabsList>
        <TabsContent value="files" className="mt-4 space-y-2">
          {!files.length ? (
            <EmptyState title={t(loc, "emptyFiles")} hint={t(loc, "emptyFilesHint")} />
          ) : (
            files.map((f) => (
              <div key={f.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3 text-sm">
                <div>
                  <p className="font-medium">{f.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {f.kind} · {Math.round(f.size / 1024)} KB
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => open(f.id)}>
                    Open
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => void share(f.id)}>
                    Share
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => removeFile(f.id)}>
                    {t(loc, "delete")}
                  </Button>
                </div>
              </div>
            ))
          )}
        </TabsContent>
        <TabsContent value="gallery" className="mt-4">
          {!images.length ? (
            <EmptyState title={t(loc, "galleryTitle")} hint={t(loc, "emptyFilesHint")} />
          ) : (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {images.map((img) => (
                <button key={img.id} type="button" onClick={() => open(img.id)} className="overflow-hidden rounded-xl border border-border">
                  {fileUrls.get(img.id) ? (
                    <img src={fileUrls.get(img.id)} alt={img.name} className="aspect-square w-full object-cover" />
                  ) : (
                    <div className="flex aspect-square items-center justify-center bg-secondary text-xs">{img.name}</div>
                  )}
                </button>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </main>
  );
}
