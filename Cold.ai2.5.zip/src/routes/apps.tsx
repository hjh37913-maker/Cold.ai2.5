import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { bestMatch } from "@/core/fuzzy";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import { APP_CATALOG } from "@/engines/apps/catalog";

export const Route = createFileRoute("/apps")({ component: AppsPage });

function AppsPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const runTurn = useColdStore((s) => s.runTurn);
  const [q, setQ] = useState("");
  const rows = useMemo(() => {
    if (!q.trim()) return APP_CATALOG;
    const m = bestMatch(q, APP_CATALOG, (a) => a.names, 0.3);
    if (!m) return APP_CATALOG.filter((a) => a.names.some((n) => n.includes(q.toLowerCase())));
    return m.matches;
  }, [q]);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "appsTitle")} lead={t(loc, "centerLead")} />
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t(loc, "search")} />
      <ul className="space-y-2">
        {rows.map((app) => (
          <li key={app.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
            <div>
              <p className="text-sm font-medium capitalize">{app.names[0]}</p>
              <p className="text-xs text-muted-foreground">{app.description}</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={() => void runTurn(loc === "uk" ? `відкрий ${app.names[0]}` : `open ${app.names[0]}`)}>
                {t(loc, "run")}
              </Button>
              {app.settingsUrl ? (
                <Button size="sm" variant="outline" onClick={() => window.open(app.settingsUrl, "_blank", "noopener")}>
                  Info
                </Button>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
