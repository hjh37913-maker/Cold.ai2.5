import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/chat")({ component: ChatPage });

function ChatPage() {
  const locale = useColdStore((s) => s.settings.locale);
  const messages = useColdStore((s) => s.messages);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(locale, "navChat")} lead={t(locale, "emptyChatHint")} />
      {!messages.length ? (
        <EmptyState title={t(locale, "emptyChat")} hint={t(locale, "emptyChatHint")} />
      ) : (
        <ol className="flex flex-col gap-3">
          {messages.map((m) => (
            <li
              key={m.id}
              className={cn(
                "max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
                m.role === "user"
                  ? "self-end bg-primary text-primary-foreground"
                  : "self-start border border-border bg-card",
              )}
            >
              {m.text}
            </li>
          ))}
        </ol>
      )}
    </main>
  );
}
