import assert from "node:assert/strict";
import { test } from "node:test";
import { parseClock, parseDurationMs } from "./datetime.ts";

test("parses 10 minutes", () => {
  assert.equal(parseDurationMs("таймер на 10 хвилин"), 600000);
});

test("parses half hour", () => {
  assert.equal(parseDurationMs("півгодини"), 1800000);
});

test("invalid timer", () => {
  assert.equal(parseDurationMs("просто текст"), null);
});

test("parses 18:00", () => {
  const c = parseClock("нагадай о 18:00");
  assert.deepEqual(c, { hour: 18, minute: 0 });
});
