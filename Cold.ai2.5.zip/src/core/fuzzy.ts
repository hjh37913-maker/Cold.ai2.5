import { normalize, stripDiacritics } from "./normalize.ts";

export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = i - 1;
    row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = row[j]!;
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      row[j] = Math.min(row[j]! + 1, row[j - 1]! + 1, prev + cost);
      prev = tmp;
    }
  }
  return row[b.length]!;
}

export function similarity(a: string, b: string): number {
  const left = stripDiacritics(normalize(a));
  const right = stripDiacritics(normalize(b));
  if (!left || !right) return 0;
  if (left === right) return 1;
  if (left.includes(right) || right.includes(left)) {
    return Math.min(left.length, right.length) / Math.max(left.length, right.length) + 0.15;
  }
  const max = Math.max(left.length, right.length);
  return Math.max(0, 1 - levenshtein(left, right) / max);
}

export function bestMatch<T>(
  query: string,
  items: T[],
  getName: (item: T) => string | string[],
  threshold = 0.55,
): { item: T; score: number; matches: T[] } | null {
  const scored = items
    .map((item) => {
      const names = getName(item);
      const list = Array.isArray(names) ? names : [names];
      const score = Math.max(...list.map((n) => similarity(query, n)));
      return { item, score };
    })
    .filter((x) => x.score >= threshold)
    .sort((a, b) => b.score - a.score);

  if (!scored.length) return null;
  const top = scored[0]!;
  const near = scored.filter((x) => top.score - x.score < 0.08 && x.score >= threshold);
  return { item: top.item, score: top.score, matches: near.map((x) => x.item) };
}
