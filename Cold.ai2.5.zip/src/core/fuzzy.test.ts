import assert from "node:assert/strict";
import { test } from "node:test";
import { bestMatch } from "./fuzzy.ts";

test("fuzzy app match", () => {
  const apps = [
    { id: "tg", names: ["telegram", "телеграм"] },
    { id: "sp", names: ["spotify"] },
  ];
  const m = bestMatch("телеграм", apps, (a) => a.names);
  assert.equal(m?.item.id, "tg");
});

test("does not guess weak matches", () => {
  const m = bestMatch("xyz", [{ id: "a", names: ["chrome"] }], (a) => a.names, 0.8);
  assert.equal(m, null);
});
