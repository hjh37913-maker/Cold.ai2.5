import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import type { PermissionId } from "@/core/types";

export const Route = createFileRoute("/privacy")({ component: PrivacyPage });

const PERMS: { id: PermissionId; query?: PermissionName; label: string; reasonKey: string }[] = [
  { id: "microphone", query: "microphone" as PermissionName, label: "Microphone", reasonKey: "permissionMic" },
  { id: "camera", query: "camera" as PermissionName, label: "Camera", reasonKey: "permissionCam" },
  { id: "geolocation", query: "geolocation" as PermissionName, label: "Location", reasonKey: "permissionLoc" },
  { id: "notifications", query: "notifications" as PermissionName, label: "Notifications", reasonKey: "permissionNotif" },
  { id: "contacts", label: "Contacts", reasonKey: "permissionContacts" },
  { id: "clipboard", label: "Clipboard", reasonKey: "setPrivacy" },
  { id: "storage", label: "Storage", reasonKey: "filesTitle" },
];

function PrivacyPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const [states, setStates] = useState<Record<string, string>>({});

  const refresh = async () => {
    const next: Record<string, string> = {};
    for (const p of PERMS) {
      if (p.query && navigator.permissions) {
        try {
          const st = await navigator.permissions.query({ name: p.query });
          next[p.id] = st.state;
        } catch {
          next[p.id] = "unknown";
        }
      } else next[p.id] = "local";
    }
    setStates(next);
  };

  useEffect(() => {
    void refresh();
  }, []);

  const request = async (id: PermissionId) => {
    try {
      if (id === "microphone") await navigator.mediaDevices.getUserMedia({ audio: true }).then((s) => s.getTracks().forEach((t) => t.stop()));
      if (id === "camera") await navigator.mediaDevices.getUserMedia({ video: true }).then((s) => s.getTracks().forEach((t) => t.stop()));
      if (id === "geolocation") await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(() => res(null), rej));
      if (id === "notifications" && typeof Notification !== "undefined") await Notification.requestPermission();
    } catch {
      /* denied */
    }
    await refresh();
  };

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "privacyTitle")} lead={t(loc, "privacyLead")} />
      <ul className="space-y-2">
        {PERMS.map((p) => (
          <li key={p.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
            <div>
              <p className="text-sm font-medium">{p.label}</p>
              <p className="text-xs text-muted-foreground">{t(loc, p.reasonKey)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge>{states[p.id] ?? "—"}</Badge>
              <Button size="sm" variant="outline" onClick={() => void request(p.id)}>
                {t(loc, "grant")}
              </Button>
            </div>
          </li>
        ))}
      </ul>
      <p className="text-sm text-muted-foreground">{t(loc, "limitationBody")}</p>
    </main>
  );
}
