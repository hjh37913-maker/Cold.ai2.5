import type { ReactNode } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Calendar, Moon, Timer, Wifi, WifiOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import { formatDuration } from "@/core/datetime";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const locale = useColdStore((s) => s.settings.locale);
  const assistant = useColdStore((s) => s.assistant);
  const lastCommand = useColdStore((s) => s.lastCommand);
  const lastReply = useColdStore((s) => s.lastReply);
  const online = useColdStore((s) => s.online);
  const tasks = useColdStore((s) => s.tasks);
  const activeTaskId = useColdStore((s) => s.activeTaskId);
  const runTurn = useColdStore((s) => s.runTurn);
  const runRoutine = useColdStore((s) => s.runRoutine);
  const timers = useColdStore((s) => s.timers);
  const focusMode = useColdStore((s) => s.focusMode);
  const showDiag = useColdStore((s) => s.settings.showDiagnosticsOnHome);
  const cores = typeof navigator === "undefined" ? 0 : navigator.hardwareConcurrency || 0;
  const task = tasks.find((x) => x.id === activeTaskId) ?? tasks[0];
  const running = task && !["SUCCESS", "FAILED", "CANCELLED"].includes(task.state);
  const done = task ? task.steps.filter((s) => s.state === "SUCCESS").length : 0;

  const quick = [
    { label: locale === "uk" ? "Ранок" : "Morning", onClick: () => void runRoutine("good_morning") },
    { label: locale === "uk" ? "Ніч" : "Night", onClick: () => void runRoutine("good_night") },
    { label: t(locale, "timersTitle"), onClick: () => void runTurn(locale === "uk" ? "постав таймер на 10 хвилин" : "set a timer for 10 minutes") },
    { label: t(locale, "calendarTitle"), to: "/productivity" },
  ];

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-8 px-5 py-8 md:py-12">
      <header className="space-y-3">
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">COLD AI</p>
        <h1 className="font-display text-5xl font-medium tracking-tight md:text-6xl">COLD</h1>
        <p className="text-sm text-muted-foreground">{t(locale, "tagline")}</p>
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <Badge tone={assistant === "idle" ? "neutral" : "ok"}>{t(locale, assistant)}</Badge>
          <Badge tone={online ? "ok" : "warn"}>
            {online ? <Wifi className="mr-1 size-3" /> : <WifiOff className="mr-1 size-3" />}
            {online ? t(locale, "online") : t(locale, "offline")}
          </Badge>
          {focusMode ? <Badge tone="warn">{t(locale, "catAutomation")}</Badge> : null}
        </div>
      </header>

      <section className="grid gap-3 sm:grid-cols-2">
        <article className="rounded-2xl border border-border bg-card p-5">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">{t(locale, "lastCommand")}</p>
          <p className="mt-2 text-base leading-relaxed">{lastCommand || t(locale, "noCommand")}</p>
          {lastReply ? <p className="mt-2 text-sm text-muted-foreground">{lastReply}</p> : null}
        </article>
        <article className="rounded-2xl border border-border bg-card p-5">
          <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">{t(locale, "currentTask")}</p>
          {running && task ? (
            <div className="mt-2 space-y-3">
              <p className="text-base">{task.title}</p>
              <p className="text-sm text-muted-foreground">
                {t(locale, "stepOf", { n: Math.min(done + 1, task.steps.length), total: task.steps.length })}
              </p>
              <Progress value={task.steps.length ? (done / task.steps.length) * 100 : 0} />
              <Link to="/task" className="text-sm font-medium text-primary">
                {t(locale, "taskTitle")}
              </Link>
            </div>
          ) : (
            <p className="mt-2 text-base text-muted-foreground">{t(locale, "noTask")}</p>
          )}
        </article>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">{t(locale, "quickActions")}</h2>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {quick.map((q) =>
            "to" in q && q.to ? (
              <Link
                key={q.label}
                to={q.to}
                className="flex min-h-14 items-center justify-center rounded-xl border border-border bg-card px-3 text-sm font-medium hover:bg-secondary"
              >
                {q.label}
              </Link>
            ) : (
              <button
                key={q.label}
                type="button"
                onClick={q.onClick}
                className="flex min-h-14 items-center justify-center rounded-xl border border-border bg-card px-3 text-sm font-medium hover:bg-secondary"
              >
                {q.label}
              </button>
            ),
          )}
        </div>
      </section>

      {timers.some((tm) => tm.running) ? (
        <section className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Timer className="size-4" />
            {t(locale, "timersTitle")}
          </div>
          <ul className="mt-3 space-y-1 text-sm tabular-nums">
            {timers
              .filter((tm) => tm.running)
              .map((tm) => (
                <li key={tm.id} className="flex justify-between">
                  <span>{tm.label}</span>
                  <span>{formatDuration(tm.remainingMs)}</span>
                </li>
              ))}
          </ul>
        </section>
      ) : null}

      {showDiag ? (
        <section>
          <h2 className="mb-3 text-sm font-medium text-muted-foreground">{t(locale, "systemStatus")}</h2>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatusChip label={t(locale, "online")} value={online ? t(locale, "online") : t(locale, "offline")} />
            <StatusChip label="CPU" value={cores ? `${cores}` : "—"} />
            <StatusChip label={t(locale, "calendarTitle")} value={<Calendar className="size-3.5" />} />
            <StatusChip label="Focus" value={focusMode ? t(locale, "enabled") : t(locale, "disabled")} />
          </div>
        </section>
      ) : null}

      <p className="flex items-center gap-2 text-xs text-muted-foreground">
        <Moon className="size-3.5" />
        {t(locale, "limitationBody")}
      </p>
    </main>
  );
}

function StatusChip({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card px-3 py-3">
      <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}
