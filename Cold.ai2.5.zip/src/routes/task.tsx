import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";

export const Route = createFileRoute("/task")({ component: TaskPage });

function TaskPage() {
  const locale = useColdStore((s) => s.settings.locale);
  const tasks = useColdStore((s) => s.tasks);
  const active = useColdStore((s) => s.tasks.find((x) => x.id === s.activeTaskId) ?? s.tasks[0]);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(locale, "taskTitle")} lead={t(locale, "preparing")} />
      {!active ? (
        <EmptyState title={t(locale, "noTask")} />
      ) : (
        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-display text-xl">{active.title}</h2>
            <Badge>{active.state}</Badge>
          </div>
          <Progress
            className="mt-4"
            value={active.steps.length ? (active.steps.filter((s) => s.state === "SUCCESS").length / active.steps.length) * 100 : 0}
          />
          <ol className="mt-5 space-y-3">
            {active.steps.map((step) => (
              <li key={step.id} className="flex gap-3 text-sm">
                <span className="tabular-nums text-muted-foreground">{step.index}/{active.steps.length}</span>
                <div>
                  <p className="font-medium">{step.label}</p>
                  <p className="text-muted-foreground">{step.result || step.error || step.state}</p>
                </div>
              </li>
            ))}
          </ol>
        </article>
      )}
      {tasks.length > 1 ? (
        <section className="space-y-2">
          <h2 className="text-sm font-medium text-muted-foreground">{t(locale, "historyTitle")}</h2>
          {tasks.slice(0, 12).map((tk) => (
            <div key={tk.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3 text-sm">
              <span>{tk.title}</span>
              <Badge tone={tk.state === "SUCCESS" ? "ok" : tk.state === "FAILED" ? "danger" : "neutral"}>{tk.state}</Badge>
            </div>
          ))}
        </section>
      ) : null}
    </main>
  );
}
