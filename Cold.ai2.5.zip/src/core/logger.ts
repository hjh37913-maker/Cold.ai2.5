export type LogCategory =
  | "VOICE"
  | "AI"
  | "TASK"
  | "ANDROID"
  | "PERMISSION"
  | "MEMORY"
  | "AUTOMATION"
  | "ERROR"
  | "SYSTEM";

export interface LogEntry {
  id: string;
  at: number;
  category: LogCategory;
  level: "debug" | "info" | "warn" | "error";
  message: string;
  data?: Record<string, unknown>;
}

const MAX = 400;
const buffer: LogEntry[] = [];
const isDev = typeof import.meta !== "undefined" && Boolean(import.meta.env?.DEV);

function push(entry: Omit<LogEntry, "id" | "at"> & { at?: number }): void {
  const row: LogEntry = {
    id: `log_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    at: entry.at ?? Date.now(),
    category: entry.category,
    level: entry.level,
    message: entry.message,
    data: entry.data,
  };
  buffer.push(row);
  if (buffer.length > MAX) buffer.splice(0, buffer.length - MAX);
  if (!isDev && row.level === "debug") return;
  const payload = row.data ? [row.message, row.data] : [row.message];
  if (row.level === "error") console.error(`[COLD:${row.category}]`, ...payload);
  else if (row.level === "warn") console.warn(`[COLD:${row.category}]`, ...payload);
  else if (isDev) console.info(`[COLD:${row.category}]`, ...payload);
}

export const logger = {
  debug: (category: LogCategory, message: string, data?: Record<string, unknown>) =>
    push({ category, level: "debug", message, data }),
  info: (category: LogCategory, message: string, data?: Record<string, unknown>) =>
    push({ category, level: "info", message, data }),
  warn: (category: LogCategory, message: string, data?: Record<string, unknown>) =>
    push({ category, level: "warn", message, data }),
  error: (category: LogCategory, message: string, data?: Record<string, unknown>) =>
    push({ category, level: "error", message, data }),
  recent: (category?: LogCategory, limit = 80): LogEntry[] => {
    const rows = category ? buffer.filter((x) => x.category === category) : buffer;
    return rows.slice(-limit);
  },
  clear: () => {
    buffer.length = 0;
  },
};
