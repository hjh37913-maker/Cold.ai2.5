export type Locale = "uk" | "en" | "pl" | "de";
export type ThemeMode = "system" | "light" | "dark";
export type AssistantState =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "executing"
  | "awaiting";

export type TaskState =
  | "QUEUED"
  | "PLANNING"
  | "WAITING_PERMISSION"
  | "WAITING_INPUT"
  | "WAITING_CONFIRMATION"
  | "EXECUTING"
  | "VERIFYING"
  | "SUCCESS"
  | "FAILED"
  | "CANCELLED"
  | "PAUSED";

export type OrchestratorKind =
  | "conversation"
  | "local_action"
  | "task_plan"
  | "web_task"
  | "system_task"
  | "automation"
  | "memory"
  | "question"
  | "clarification";

export type MemoryCategory =
  | "preferences"
  | "people"
  | "routines"
  | "projects"
  | "facts"
  | "commands";

export type PermissionId =
  | "microphone"
  | "camera"
  | "geolocation"
  | "notifications"
  | "contacts"
  | "clipboard"
  | "storage";

export type ActionKind =
  | "open_app"
  | "open_url"
  | "search_web"
  | "search_youtube"
  | "search_maps"
  | "navigate"
  | "call"
  | "sms"
  | "email"
  | "timer_create"
  | "timer_cancel"
  | "timer_list"
  | "stopwatch_start"
  | "stopwatch_stop"
  | "stopwatch_reset"
  | "alarm_create"
  | "alarm_list"
  | "alarm_cancel"
  | "reminder_create"
  | "reminder_list"
  | "reminder_cancel"
  | "event_create"
  | "event_list"
  | "event_delete"
  | "volume_set"
  | "media_play"
  | "media_pause"
  | "media_next"
  | "media_prev"
  | "flashlight"
  | "camera_open"
  | "file_search"
  | "file_open"
  | "file_share"
  | "file_delete"
  | "gallery_recent"
  | "gallery_open"
  | "contact_search"
  | "contact_add"
  | "notification_list"
  | "diagnostics_report"
  | "weather"
  | "translate"
  | "calculate"
  | "memory_save"
  | "memory_forget"
  | "memory_list"
  | "routine_run"
  | "automation_run"
  | "custom_command_run"
  | "ai_respond"
  | "settings_open"
  | "focus_mode"
  | "ask_user"
  | "confirm"
  | "clipboard_copy"
  | "history_query"
  | "none";

export interface PlannedAction {
  id: string;
  kind: ActionKind;
  label: string;
  args: Record<string, unknown>;
  requiresPermission?: PermissionId;
  requiresConfirmation?: boolean;
  optional?: boolean;
}

export interface TaskStep {
  id: string;
  index: number;
  label: string;
  action: PlannedAction;
  state: TaskState;
  result?: string;
  error?: string;
}

export interface ColdTask {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  state: TaskState;
  steps: TaskStep[];
  sourceText: string;
  reply?: string;
  error?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  at: number;
  taskId?: string;
  kind?: OrchestratorKind;
}

export interface MemoryItem {
  id: string;
  category: MemoryCategory;
  title: string;
  value: string;
  createdAt: number;
  updatedAt: number;
}

export interface Contact {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  notes?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: number;
  end: number;
  location?: string;
  notes?: string;
}

export interface Reminder {
  id: string;
  title: string;
  at: number;
  done: boolean;
  fired: boolean;
}

export interface Alarm {
  id: string;
  label: string;
  hour: number;
  minute: number;
  enabled: boolean;
  days: number[];
  nextAt: number;
  firedAt?: number;
}

export interface TimerItem {
  id: string;
  label: string;
  durationMs: number;
  remainingMs: number;
  running: boolean;
  createdAt: number;
  endsAt?: number;
}

export interface StopwatchState {
  running: boolean;
  elapsedMs: number;
  startedAt?: number;
}

export interface AppEntry {
  id: string;
  names: string[];
  url: string;
  category: string;
  description: string;
  settingsUrl?: string;
}

export interface IndexedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  addedAt: number;
  lastOpenedAt?: number;
  kind: "document" | "image" | "audio" | "video" | "other";
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  source: string;
  at: number;
  important: boolean;
  read: boolean;
  category: "system" | "message" | "reminder" | "media" | "other";
}

export interface Automation {
  id: string;
  name: string;
  enabled: boolean;
  trigger: AutomationTrigger;
  actions: PlannedAction[];
  lastRunAt?: number;
  runCount: number;
}

export type AutomationTrigger =
  | { type: "voice"; phrase: string }
  | { type: "manual" }
  | { type: "schedule"; hour: number; minute: number; days: number[] }
  | { type: "app_open"; appId: string }
  | { type: "event"; event: "online" | "offline" | "focus" | "startup" };

export interface Routine {
  id: string;
  key: string;
  name: string;
  description: string;
  actions: PlannedAction[];
  editable: boolean;
}

export interface CustomCommand {
  id: string;
  phrase: string;
  description: string;
  actions: PlannedAction[];
  enabled: boolean;
}

export interface HistoryEntry {
  id: string;
  at: number;
  type: "command" | "task" | "error" | "automation" | "conversation";
  title: string;
  detail: string;
  ok: boolean;
}

export interface ConversationContext {
  lastAppId?: string;
  lastIntent?: ActionKind;
  lastDurationMs?: number;
  lastContactId?: string;
  lastPlace?: string;
  lastQuery?: string;
  lastVolume?: number;
  pendingQuestion?: string;
  pendingAction?: PlannedAction;
  entities: string[];
}

export interface PermissionState {
  id: PermissionId;
  state: "unknown" | "granted" | "denied" | "prompt";
  lastAskedAt?: number;
}

export interface VoiceSettings {
  locale: Locale;
  autoListen: boolean;
  wakeWord: boolean;
  wakePhrase: string;
  ttsEnabled: boolean;
  neuralTts: boolean;
  rate: number;
  pitch: number;
  volume: number;
}

export interface AiSettings {
  provider: "xai" | "openai-compatible" | "local";
  model: string;
  useForLocalCommands: boolean;
  maxHistory: number;
}

export interface ConfirmationRequest {
  id: string;
  title: string;
  body: string;
  confirmLabel: string;
  cancelLabel: string;
  action: PlannedAction;
  taskId?: string;
}

export interface PermissionRequest {
  id: string;
  permission: PermissionId;
  reason: string;
  action?: PlannedAction;
  taskId?: string;
}

export interface AnalyticsSnapshot {
  commands: number;
  success: number;
  errors: number;
  automations: number;
  byKind: Record<string, number>;
}

export interface ColdSettings {
  locale: Locale;
  theme: ThemeMode;
  reducedMotion: boolean;
  largeText: boolean;
  confirmSensitive: boolean;
  offlinePreferLocal: boolean;
  performanceMode: boolean;
  showDiagnosticsOnHome: boolean;
}

export interface OrchestratorDecision {
  kind: OrchestratorKind;
  reply: string;
  speak?: string;
  actions: PlannedAction[];
  planTitle?: string;
  question?: string;
  confidence: number;
  usedAi: boolean;
}
