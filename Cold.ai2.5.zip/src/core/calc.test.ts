import assert from "node:assert/strict";
import { test } from "node:test";
import { evaluateMath, looksLikeMath } from "./calc.ts";

test("multiplies numbers", () => {
  const r = evaluateMath("235 * 48");
  assert.equal(r.ok, true);
  if (r.ok) assert.equal(r.value, "11280");
});

test("ukrainian multiply phrasing", () => {
  const r = evaluateMath("скільки буде 235 помножити на 48");
  assert.equal(r.ok, true);
  if (r.ok) assert.equal(r.value, "11280");
});

test("percent of", () => {
  const r = evaluateMath("15% від 800");
  assert.equal(r.ok, true);
  if (r.ok) assert.equal(r.value, "120");
});

test("km to miles", () => {
  const r = evaluateMath("переведи 5 кілометрів у miles");
  assert.equal(r.ok, true);
  if (r.ok) assert.match(r.value, /^3\.1/);
});

test("empty is not math", () => {
  assert.equal(looksLikeMath(""), false);
});

test("invalid expression", () => {
  const r = evaluateMath("hello");
  assert.equal(r.ok, false);
});
