import type { ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  History,
  Home,
  LayoutGrid,
  MessageSquare,
  Settings,
} from "lucide-react";
import { useEffect } from "react";
import { VoiceDock } from "@/components/cold/voice-dock";
import { Button } from "@/components/ui/button";
import { t } from "@/core/i18n";
import { stopSpeaking, useColdStore } from "@/core/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", key: "navHome", icon: Home },
  { to: "/chat", key: "navChat", icon: MessageSquare },
  { to: "/center", key: "navCenter", icon: LayoutGrid },
  { to: "/history", key: "navHistory", icon: History },
  { to: "/settings", key: "navSettings", icon: Settings },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const locale = useColdStore((s) => s.settings.locale);
  const theme = useColdStore((s) => s.settings.theme);
  const largeText = useColdStore((s) => s.settings.largeText);
  const reduced = useColdStore((s) => s.settings.reducedMotion);
  const assistant = useColdStore((s) => s.assistant);
  const confirmation = useColdStore((s) => s.confirmation);
  const confirmPending = useColdStore((s) => s.confirmPending);
  const cancelPending = useColdStore((s) => s.cancelPending);
  const tick = useColdStore((s) => s.tick);
  const setOnline = useColdStore((s) => s.setOnline);
  const setHydrated = useColdStore((s) => s.setHydrated);
  const pendingNavigate = useColdStore((s) => s.pendingNavigate);
  const consumeNavigate = useColdStore((s) => s.consumeNavigate);
  const performanceMode = useColdStore((s) => s.settings.performanceMode);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();

  useEffect(() => {
    setHydrated();
  }, [setHydrated]);

  useEffect(() => {
    const root = document.documentElement;
    const apply = () => {
      const dark =
        theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
      root.classList.toggle("dark", dark);
    };
    apply();
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [theme]);

  useEffect(() => {
    document.documentElement.classList.toggle("large-text", largeText);
    document.documentElement.classList.toggle("reduce-motion", reduced);
  }, [largeText, reduced]);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    setOnline(navigator.onLine);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, [setOnline]);

  useEffect(() => {
    const ms = performanceMode ? 4000 : 1000;
    const id = window.setInterval(() => tick(), ms);
    return () => window.clearInterval(id);
  }, [tick, performanceMode]);

  useEffect(() => {
    if (!pendingNavigate) return;
    const path = consumeNavigate();
    if (path) void navigate({ to: path });
  }, [pendingNavigate, consumeNavigate, navigate]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") stopSpeaking();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="flex min-h-dvh bg-background text-foreground">
      <aside className="hidden w-56 shrink-0 flex-col border-r border-border bg-card px-3 py-6 md:flex">
        <Link to="/" className="px-3">
          <p className="font-display text-2xl font-medium tracking-tight">COLD</p>
          <p className="text-xs text-muted-foreground">AI</p>
        </Link>
        <nav className="mt-8 flex flex-col gap-1" aria-label="Main">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors",
                  active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground",
                )}
              >
                <Icon className="size-4" />
                {t(locale, item.key)}
              </Link>
            );
          })}
        </nav>
        <p className="mt-auto px-3 text-xs text-muted-foreground" aria-live="polite">
          {t(locale, assistant)}
        </p>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="min-h-0 flex-1 overflow-y-auto pb-24 md:pb-0">{children}</div>
        <VoiceDock />
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-card/95 px-2 py-1 backdrop-blur-sm md:hidden"
        style={{ paddingBottom: "max(0.4rem, env(safe-area-inset-bottom))" }}
        aria-label="Main"
      >
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-h-12 flex-1 flex-col items-center justify-center gap-0.5 text-[11px]",
                active ? "text-foreground" : "text-muted-foreground",
              )}
            >
              <Icon className="size-4" />
              {t(locale, item.key)}
            </Link>
          );
        })}
      </nav>

      {confirmation ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/30 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-lg">
            <h2 className="font-display text-xl font-medium">{confirmation.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{confirmation.body}</p>
            <div className="mt-5 flex gap-2">
              <Button className="flex-1" onClick={() => void confirmPending()}>
                {confirmation.confirmLabel}
              </Button>
              <Button className="flex-1" variant="outline" onClick={cancelPending}>
                {confirmation.cancelLabel}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
