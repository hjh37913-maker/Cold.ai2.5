import assert from "node:assert/strict";
import { test } from "node:test";
import { planTask, setStepState } from "./engine.ts";

test("plans queued steps", () => {
  const task = planTask("Night", "підготуй до сну", [
    { id: "a1", kind: "volume_set", label: "vol", args: { percent: 10 } },
    { id: "a2", kind: "focus_mode", label: "focus", args: { on: true } },
  ]);
  assert.equal(task.steps.length, 2);
  assert.equal(task.state, "PLANNING");
  const next = setStepState(task, task.steps[0]!.id, "FAILED", { error: "nope" });
  assert.equal(next.state, "FAILED");
});

test("task cancellation state is terminal-ready", () => {
  const task = planTask("x", "x", [{ id: "a", kind: "none", label: "n", args: {} }]);
  const cancelled = { ...task, state: "CANCELLED" as const };
  assert.equal(cancelled.state, "CANCELLED");
});
