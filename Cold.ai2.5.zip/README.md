# COLD AI

Personal operating assistant: listen, understand, plan, execute, remember.

COLD is not a chatbot. It routes natural language into local actions, multi-step task plans, memory, automations, and AI — with confirmation for anything sensitive.

This build runs as a professional web app (installable on Android via the browser). Native Play Store packaging is not produced in this environment.

## Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md). Engines are modular: Voice, Intent, Context, AI, Planner, Executor, Memory, Automation, Apps, Calendar, Files, Web, Permissions, Diagnostics, UI.

## Setup

No API keys are hardcoded. The xAI key is injected by the host at runtime (`XAI_API_KEY`, server-only). Weather uses Open-Meteo (no key).

## Build

```
npm run dev
npm run build
npm run typecheck
npm test
```

## Permissions

Asked only when a task needs them: microphone, camera, location, notifications, contacts (local store). Never at first launch.

## AI configuration

Provider abstraction: xAI Grok (`grok-4.5`) now; OpenAI-compatible and local later. Settings → AI.

## Testing

Unit tests cover calculator, datetime, fuzzy match, intent (empty input, timers, duplicate contacts, multi-step, memory), memory engine, planner.

## Release

Production build: `npm run build`. Do not log secrets. Sensitive actions require confirmation.
