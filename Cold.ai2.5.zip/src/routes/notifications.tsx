import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";

export const Route = createFileRoute("/notifications")({ component: NotificationsPage });

function NotificationsPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const items = useColdStore((s) => s.notifications);
  const mark = useColdStore((s) => s.markNotification);
  const [filter, setFilter] = useState<"all" | "important" | "unread">("all");
  const rows = items.filter((n) => {
    if (filter === "important") return n.important;
    if (filter === "unread") return !n.read;
    return true;
  });

  const ask = async () => {
    if (typeof Notification === "undefined") return;
    await Notification.requestPermission();
  };

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader
        title={t(loc, "notificationsTitle")}
        actions={
          <Button variant="outline" onClick={() => void ask()}>
            {t(loc, "grant")}
          </Button>
        }
      />
      <div className="flex gap-2">
        {(["all", "important", "unread"] as const).map((f) => (
          <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>
            {t(loc, f === "all" ? "all" : f === "important" ? "important" : "unread")}
          </Button>
        ))}
      </div>
      {!rows.length ? (
        <EmptyState title={t(loc, "emptyNotifications")} />
      ) : (
        <ul className="space-y-2">
          {rows.map((n) => (
            <li key={n.id} className="rounded-xl border border-border bg-card px-4 py-3" onClick={() => mark(n.id)}>
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{n.title}</p>
                {n.important ? <Badge tone="warn">{t(loc, "important")}</Badge> : null}
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{n.body}</p>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
