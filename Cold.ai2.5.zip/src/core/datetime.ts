import { normalize } from "./normalize.ts";

const WORD_NUM: Record<string, number> = {
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  fifteen: 15,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fortyfive: 45,
  sixty: 60,
  один: 1,
  одна: 1,
  одну: 1,
  два: 2,
  дві: 2,
  три: 3,
  чотири: 4,
  п'ять: 5,
  пять: 5,
  шість: 6,
  сім: 7,
  вісім: 8,
  дев'ять: 9,
  девять: 9,
  десять: 10,
  п'ятнадцять: 15,
  пятнадцять: 15,
  двадцять: 20,
  тридцять: 30,
  сорок: 40,
  сорокп'ять: 45,
  пів: 0.5,
  pol: 0.5,
  jeden: 1,
  dwa: 2,
  trzy: 3,
  piec: 5,
  dziesiec: 10,
  piecdziesiat: 15,
  dreisig: 30,
  eins: 1,
  zwei: 2,
  drei: 3,
  funf: 5,
  zehn: 10,
};

function wordToNum(token: string): number | null {
  const n = Number(token.replace(",", "."));
  if (Number.isFinite(n)) return n;
  return WORD_NUM[token] ?? WORD_NUM[token.replace("'", "")] ?? null;
}

export function parseDurationMs(raw: string): number | null {
  const t = normalize(raw);
  if (/півгодин|half an hour|pol godziny|halbe stunde/.test(t)) return 30 * 60_000;
  if (/\bгодин[ауеи]?\b|\bhour\b|\bgodziny?\b|\bstunde\b/.test(t) && /пів|half|pol|halb/.test(t)) {
    return 30 * 60_000;
  }

  const combo = t.match(
    /(?:(\d+|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)\s*(?:год(?:ин[ауеи]?)?|h|hours?|godzin[aye]?|stunden?)\s*)?(?:(\d+|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)\s*(?:хв(?:илин[ауи]?)?|min(?:ute)?s?|minut[aye]?|minuten?))?(?:\s*(\d+|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)\s*(?:сек(?:унд[ауи]?)?|sec(?:ond)?s?|sekund[aye]?|sekunden?))?/,
  );

  const hm = t.match(/(\d+)\s*:\s*(\d{2})/);
  if (hm && /таймер|timer|timer|min/.test(t) === false && false) {
    /* keep duration parser focused */
  }

  let hours = 0;
  let minutes = 0;
  let seconds = 0;
  const h = t.match(/(\d+(?:[.,]\d+)?|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)\s*(?:год(?:ин[ауеи]?)?|hours?|h\b|godzin[aye]?|stunden?)/);
  const m = t.match(/(\d+(?:[.,]\d+)?|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)\s*(?:хв(?:илин[ауи]?)?|min(?:ute)?s?|minut[aye]?|minuten?)/);
  const s = t.match(/(\d+(?:[.,]\d+)?|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)\s*(?:сек(?:унд[ауи]?)?|sec(?:ond)?s?|sekund[aye]?|sekunden?)/);
  if (h) hours = wordToNum(h[1]!) ?? 0;
  if (m) minutes = wordToNum(m[1]!) ?? 0;
  if (s) seconds = wordToNum(s[1]!) ?? 0;

  if (!h && !m && !s) {
    const lone = t.match(/(?:на|for|auf|na)\s+(\d+(?:[.,]\d+)?|[a-zA-Zа-яА-ЯіІїЇєЄ'ґҐ]+)/);
    if (lone) {
      const n = wordToNum(lone[1]!);
      if (n) minutes = n;
    } else if (combo) {
      /* handled below */
    }
  }

  const total = hours * 3_600_000 + minutes * 60_000 + seconds * 1000;
  if (total > 0) return total;
  const n = t.match(/(\d+)/);
  if (n && /таймер|timer|хвилин|минут|min/.test(t)) return Number(n[1]) * 60_000;
  return null;
}

export function parseClock(raw: string, now = new Date()): { hour: number; minute: number } | null {
  const t = normalize(raw);
  const hm = t.match(/\b([01]?\d|2[0-3])[:.]([0-5]\d)\b/);
  if (hm) return { hour: Number(hm[1]), minute: Number(hm[2]) };
  const ampm = t.match(/\b([1-9]|1[0-2])\s*(am|pm|ранку|вечора|дня)\b/);
  if (ampm) {
    let hour = Number(ampm[1]);
    const suf = ampm[2];
    if (suf === "pm" || suf === "вечора" || suf === "дня") {
      if (hour < 12) hour += 12;
    }
    if ((suf === "am" || suf === "ранку") && hour === 12) hour = 0;
    return { hour, minute: 0 };
  }
  const at = t.match(/(?:о|at|um|o)\s+([01]?\d|2[0-3])\b/);
  if (at) return { hour: Number(at[1]), minute: 0 };
  const na = t.match(/(?:на|for)\s+([01]?\d|2[0-3])\b/);
  if (na && /будильник|alarm|budzik|wecker/.test(t)) return { hour: Number(na[1]), minute: 0 };
  void now;
  return null;
}

export function nextDateFromText(raw: string, now = new Date()): Date | null {
  const t = normalize(raw);
  const base = new Date(now.getTime());
  if (/післязавтра|day after tomorrow|pojutrze|übermorgen/.test(t)) {
    base.setDate(base.getDate() + 2);
  } else if (/завтра|tomorrow|jutro|morgen/.test(t)) {
    base.setDate(base.getDate() + 1);
  } else if (/сьогодні|today|dzisiaj|heute/.test(t)) {
    /* same day */
  }

  const inMs = parseDurationMs(t);
  if (/через|in\s+\d|za\s+\d|in\s+/.test(t) && inMs) {
    return new Date(now.getTime() + inMs);
  }

  const clock = parseClock(t, now);
  if (clock) {
    base.setHours(clock.hour, clock.minute, 0, 0);
    if (base.getTime() <= now.getTime() && !/завтра|tomorrow|jutro|morgen|післязавтра/.test(t)) {
      base.setDate(base.getDate() + 1);
    }
    return base;
  }

  if (/завтра|tomorrow|jutro|morgen|післязавтра|сьогодні|today/.test(t)) {
    if (!clock) return null;
  }
  return null;
}

export function nextAlarmAt(hour: number, minute: number, now = new Date()): number {
  const next = new Date(now.getTime());
  next.setHours(hour, minute, 0, 0);
  if (next.getTime() <= now.getTime()) next.setDate(next.getDate() + 1);
  return next.getTime();
}

export function startOfDay(ts = Date.now()): number {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function endOfDay(ts = Date.now()): number {
  const d = new Date(ts);
  d.setHours(23, 59, 59, 999);
  return d.getTime();
}

export function formatTime(ts: number, locale: string): string {
  return new Date(ts).toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
}

export function formatDateTime(ts: number, locale: string): string {
  return new Date(ts).toLocaleString(locale, {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatDuration(ms: number): string {
  const s = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${m}:${String(sec).padStart(2, "0")}`;
}
