import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { t } from "@/core/i18n";
import { APP_VERSION, useColdStore } from "@/core/store";

export const Route = createFileRoute("/diagnostics")({ component: DiagnosticsPage });

function DiagnosticsPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const online = useColdStore((s) => s.online);
  const [report, setReport] = useState<Record<string, string>>({});

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      const nav = navigator as Navigator & {
        deviceMemory?: number;
        connection?: { effectiveType?: string; downlink?: number };
      };
      const storage = await navigator.storage?.estimate?.().catch(() => undefined);
      let battery = "—";
      try {
        const bat = await (navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }> }).getBattery?.();
        if (bat) battery = `${Math.round(bat.level * 100)}%${bat.charging ? " charging" : ""}`;
      } catch {
        battery = "n/a";
      }
      const mem = (performance as Performance & { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } }).memory;
      if (cancelled) return;
      setReport({
        Network: online ? t(loc, "online") : t(loc, "offline"),
        Connection: nav.connection?.effectiveType ?? "—",
        Downlink: nav.connection?.downlink ? `${nav.connection.downlink} Mbps` : "—",
        Battery: battery,
        RAM: nav.deviceMemory ? `${nav.deviceMemory} GB` : "—",
        Heap: mem ? `${Math.round(mem.usedJSHeapSize / 1048576)} / ${Math.round(mem.jsHeapSizeLimit / 1048576)} MB` : "—",
        Storage: storage?.quota ? `${Math.round((storage.usage ?? 0) / 1048576)} / ${Math.round(storage.quota / 1048576)} MB` : "—",
        CPU: String(navigator.hardwareConcurrency || "—"),
        Platform: navigator.platform,
        Language: navigator.language,
        UA: navigator.userAgent.slice(0, 80),
        App: APP_VERSION,
        Timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      });
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [loc, online]);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "diagnosticsTitle")} lead={t(loc, "checkPhone")} />
      <dl className="divide-y divide-border rounded-2xl border border-border bg-card">
        {Object.entries(report).map(([k, v]) => (
          <div key={k} className="flex items-start justify-between gap-4 px-4 py-3 text-sm">
            <dt className="text-muted-foreground">{k}</dt>
            <dd className="max-w-[60%] text-right">{v}</dd>
          </div>
        ))}
      </dl>
    </main>
  );
}
