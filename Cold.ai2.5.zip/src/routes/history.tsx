import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { t } from "@/core/i18n";
import { startOfDay } from "@/core/datetime";
import { useColdStore } from "@/core/store";
import { includesNormalized } from "@/core/normalize";

export const Route = createFileRoute("/history")({ component: HistoryPage });

function HistoryPage() {
  const locale = useColdStore((s) => s.settings.locale);
  const history = useColdStore((s) => s.history);
  const analytics = useColdStore((s) => s.analytics);
  const [q, setQ] = useState("");
  const [range, setRange] = useState<"all" | "today" | "yesterday" | "week">("all");

  const rows = useMemo(() => {
    const now = Date.now();
    return history.filter((h) => {
      if (q && !includesNormalized(h.title, q) && !includesNormalized(h.detail, q)) return false;
      if (range === "today") return h.at >= startOfDay(now);
      if (range === "yesterday") return h.at >= startOfDay(now - 86400000) && h.at < startOfDay(now);
      if (range === "week") return h.at >= startOfDay(now - 6 * 86400000);
      return true;
    });
  }, [history, q, range]);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(locale, "historyTitle")} />
      <section className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label={t(locale, "navCenter")} value={analytics.commands} />
        <Stat label={t(locale, "success")} value={analytics.success} />
        <Stat label={t(locale, "failed")} value={analytics.errors} />
        <Stat label={t(locale, "automations")} value={analytics.automations} />
      </section>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t(locale, "search")} />
        <div className="flex gap-1">
          {(["all", "today", "yesterday", "week"] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRange(r)}
              className={`min-h-11 rounded-lg px-3 text-sm ${range === r ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
            >
              {t(locale, r === "all" ? "all" : r === "today" ? "today" : r === "yesterday" ? "yesterday" : "thisWeek")}
            </button>
          ))}
        </div>
      </div>
      {!rows.length ? (
        <EmptyState title={t(locale, "emptyHistory")} />
      ) : (
        <ul className="space-y-2">
          {rows.map((h) => (
            <li key={h.id} className="rounded-xl border border-border bg-card px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-medium">{h.title}</p>
                <Badge tone={h.ok ? "ok" : "danger"}>{h.type}</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{h.detail}</p>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-border bg-card px-3 py-3">
      <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
    </div>
  );
}
