# Security

- No hardcoded API keys
- AI key is server-only (`XAI_API_KEY`)
- Microphone is used only while listening
- Sensitive actions (call, SMS, delete) require confirmation
- Permissions are requested at the moment of need
- Memory stays on-device; AI turns send only a short user-authored memory summary
- Debug logs are verbose in development and reduced in production
- No hidden recording, no bulk personal-data upload
