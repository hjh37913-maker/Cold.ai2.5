import { createFileRoute, useSearch } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { t } from "@/core/i18n";
import { uid } from "@/core/id";
import { fileBlobs, fileUrls, useColdStore } from "@/core/store";

export const Route = createFileRoute("/system")({
  validateSearch: (s: Record<string, unknown>) => ({ tab: typeof s.tab === "string" ? s.tab : "camera" }),
  component: SystemPage,
});

function SystemPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const flashlightOn = useColdStore((s) => s.flashlightOn);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [camError, setCamError] = useState("");

  const startCam = async () => {
    setCamError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch {
      setCamError(t(loc, "permissionCam"));
    }
  };

  const stopCam = () => {
    streamRef.current?.getTracks().forEach((tr) => tr.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  };

  const capture = () => {
    const video = videoRef.current;
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const file = new File([blob], `cold-${Date.now()}.jpg`, { type: "image/jpeg" });
      const id = uid("file");
      fileBlobs.set(id, file);
      fileUrls.set(id, URL.createObjectURL(file));
      useColdStore.getState().addFiles([
        { id, name: file.name, type: file.type, size: file.size, addedAt: Date.now(), kind: "image" },
      ]);
    }, "image/jpeg");
  };

  const torch = async (on: boolean) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      const track = stream.getVideoTracks()[0];
      await track?.applyConstraints({ advanced: [{ torch: on } as MediaTrackConstraintSet] });
      if (!on) stream.getTracks().forEach((tr) => tr.stop());
      useColdStore.setState({ flashlightOn: on });
    } catch {
      useColdStore.setState({ flashlightOn: on });
    }
  };

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "catSystem")} />
      <section className="space-y-3 rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display text-lg">Camera</h2>
        <video ref={videoRef} autoPlay playsInline muted className="aspect-video w-full rounded-xl bg-secondary object-cover" />
        {camError ? <p className="text-sm text-destructive">{camError}</p> : null}
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => void startCam()}>{t(loc, "cameraOpened")}</Button>
          <Button variant="outline" onClick={capture}>
            Capture
          </Button>
          <Button variant="ghost" onClick={stopCam}>
            {t(loc, "stop")}
          </Button>
        </div>
      </section>
      <section className="space-y-3 rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display text-lg">Flashlight</h2>
        <p className="text-sm text-muted-foreground">{flashlightOn ? t(loc, "flashlightOn") : t(loc, "flashlightOff")}</p>
        <Button variant={flashlightOn ? "default" : "outline"} onClick={() => void torch(!flashlightOn)}>
          {flashlightOn ? t(loc, "flashlightOff") : t(loc, "flashlightOn")}
        </Button>
      </section>
    </main>
  );
}
