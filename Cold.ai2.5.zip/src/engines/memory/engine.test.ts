import assert from "node:assert/strict";
import { test } from "node:test";
import { forget, listMemory, remember } from "./engine.ts";

test("remember and list", () => {
  let items = remember([], "люблю темну тему", "preferences");
  assert.equal(items.length, 1);
  items = remember(items, "Іван — колега", "people");
  assert.equal(listMemory(items).length, 2);
});

test("forget by query", () => {
  let items = remember([], "секретний код 1", "facts");
  items = remember(items, "улюблений чай", "preferences");
  const res = forget(items, "секретний");
  assert.equal(res.removed.length, 1);
  assert.equal(res.items.length, 1);
});
