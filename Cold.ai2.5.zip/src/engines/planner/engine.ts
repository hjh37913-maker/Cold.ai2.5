import { uid } from "../../core/id.ts";
import type { ColdTask, PlannedAction, TaskState } from "../../core/types.ts";

export function planTask(title: string, sourceText: string, actions: PlannedAction[]): ColdTask {
  const now = Date.now();
  const id = uid("task");
  return {
    id,
    title,
    sourceText,
    createdAt: now,
    updatedAt: now,
    state: actions.length > 1 ? "PLANNING" : "QUEUED",
    steps: actions.map((action, index) => ({
      id: uid("step"),
      index: index + 1,
      label: action.label,
      action,
      state: "QUEUED" as TaskState,
    })),
  };
}

export const TERMINAL: TaskState[] = ["SUCCESS", "FAILED", "CANCELLED"];

export function setStepState(task: ColdTask, stepId: string, state: TaskState, patch?: { result?: string; error?: string }): ColdTask {
  return {
    ...task,
    updatedAt: Date.now(),
    state: state === "FAILED" || state === "CANCELLED" ? state : task.state,
    steps: task.steps.map((s) => (s.id === stepId ? { ...s, state, ...patch } : s)),
  };
}
