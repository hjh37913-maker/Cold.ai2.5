import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";

export const Route = createFileRoute("/contacts")({ component: ContactsPage });

function ContactsPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const contacts = useColdStore((s) => s.contacts);
  const add = useColdStore((s) => s.addContact);
  const remove = useColdStore((s) => s.removeContact);
  const runTurn = useColdStore((s) => s.runTurn);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "contactsTitle")} lead={t(loc, "emptyContactsHint")} />
      <form
        className="grid gap-2 rounded-2xl border border-border bg-card p-4 sm:grid-cols-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim()) return;
          add({ name: name.trim(), phone: phone.trim() || undefined, email: email.trim() || undefined });
          setName("");
          setPhone("");
          setEmail("");
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" required />
        <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" />
        <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
        <Button type="submit">{t(loc, "create")}</Button>
      </form>
      {!contacts.length ? (
        <EmptyState title={t(loc, "emptyContacts")} hint={t(loc, "emptyContactsHint")} />
      ) : (
        <ul className="space-y-2">
          {contacts.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <div>
                <p className="text-sm font-medium">{c.name}</p>
                <p className="text-xs text-muted-foreground">{c.phone || c.email}</p>
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={() => void runTurn(loc === "uk" ? `подзвони ${c.name}` : `call ${c.name}`)}>
                  {t(loc, "confirmCall")}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(c.id)}>
                  {t(loc, "delete")}
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
