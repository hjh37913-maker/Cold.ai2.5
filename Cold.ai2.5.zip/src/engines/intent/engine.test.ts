import assert from "node:assert/strict";
import { test } from "node:test";
import { parseIntent } from "./engine.ts";

const base = {
  locale: "uk" as const,
  contacts: [
    { id: "1", name: "Іван Петренко", phone: "+380111" },
    { id: "2", name: "Іван Коваль", phone: "+380222" },
  ],
};

test("empty input asks again", () => {
  const r = parseIntent({ ...base, text: "" });
  assert.equal(r.kind, "clarification");
  assert.equal(r.question, "empty");
});

test("timer with duration", () => {
  const r = parseIntent({ ...base, text: "Постав таймер на 10 хвилин" });
  assert.equal(r.actions[0]?.kind, "timer_create");
  assert.equal(r.actions[0]?.args.durationMs, 600000);
});

test("follow-up timer uses context", () => {
  const r = parseIntent({
    ...base,
    text: "ще один на 5",
    lastIntent: "timer_create",
    lastDurationMs: 600000,
  });
  assert.equal(r.actions[0]?.kind, "timer_create");
  assert.equal(r.usedContext, true);
});

test("alarm without time asks", () => {
  const r = parseIntent({ ...base, text: "постав будильник" });
  assert.equal(r.question, "alarm_time");
});

test("duplicate contacts are not guessed", () => {
  const r = parseIntent({ ...base, text: "Подзвони Івану" });
  assert.equal(r.question, "contact_ambiguous");
});

test("open youtube", () => {
  const r = parseIntent({ ...base, text: "Відкрий YouTube" });
  assert.equal(r.actions[0]?.kind, "open_app");
  assert.equal(r.actions[0]?.args.appId, "youtube");
});

test("youtube follow-up search uses context", () => {
  const r = parseIntent({ ...base, text: "знайди музику", lastAppId: "youtube" });
  assert.equal(r.actions[0]?.kind, "search_youtube");
  assert.equal(r.usedContext, true);
});

test("multi-step command", () => {
  const r = parseIntent({
    ...base,
    text: "Відкрий YouTube, знайди Minecraft і постав гучність 30%",
  });
  assert.equal(r.kind, "task_plan");
  assert.ok(r.actions.length >= 2);
});

test("reminder without subject asks", () => {
  const r = parseIntent({ ...base, text: "Нагадай завтра о 18:00" });
  assert.equal(r.question, "reminder_what");
});

test("memory save", () => {
  const r = parseIntent({ ...base, text: "Запам'ятай що я люблю тишу" });
  assert.equal(r.kind, "memory");
  assert.equal(r.actions[0]?.kind, "memory_save");
});

test("good night is a routine", () => {
  const r = parseIntent({ ...base, text: "Підготуй телефон до сну" });
  assert.equal(r.actions[0]?.kind, "routine_run");
});
