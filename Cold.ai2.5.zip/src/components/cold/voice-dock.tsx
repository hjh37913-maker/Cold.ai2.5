import { Mic, Square, ArrowUp } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { t } from "@/core/i18n";
import { localeBcp47 } from "@/core/i18n";
import { stopSpeaking, useColdStore } from "@/core/store";
import { logger } from "@/core/logger";
import { cn } from "@/lib/utils";

type Rec = {
  start: () => void;
  stop: () => void;
  abort: () => void;
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((ev: { results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
};

function makeRec(): Rec | null {
  if (typeof window === "undefined") return null;
  const C =
    (window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec })
      .SpeechRecognition ??
    (window as unknown as { webkitSpeechRecognition?: new () => Rec }).webkitSpeechRecognition;
  if (!C) return null;
  return new C();
}

export function VoiceDock() {
  const locale = useColdStore((s) => s.settings.locale);
  const assistant = useColdStore((s) => s.assistant);
  const runTurn = useColdStore((s) => s.runTurn);
  const setAssistant = useColdStore((s) => s.setAssistant);
  const voice = useColdStore((s) => s.voice);
  const [text, setText] = useState("");
  const recRef = useRef<Rec | null>(null);

  useEffect(() => {
    return () => recRef.current?.abort();
  }, []);

  const startListen = () => {
    stopSpeaking();
    const rec = makeRec();
    if (!rec) {
      setAssistant("idle");
      return;
    }
    rec.lang = localeBcp47(voice.locale);
    rec.continuous = false;
    rec.interimResults = true;
    rec.onresult = (ev) => {
      const last = ev.results[ev.results.length - 1];
      if (!last) return;
      const said = last[0].transcript;
      setText(said);
      if (last.isFinal) {
        rec.stop();
        void runTurn(said);
      }
    };
    rec.onerror = (ev) => {
      logger.warn("VOICE", "recognition error", { error: ev.error });
      setAssistant("idle");
    };
    rec.onend = () => {
      if (useColdStore.getState().assistant === "listening") setAssistant("idle");
    };
    recRef.current = rec;
    try {
      rec.start();
      setAssistant("listening");
    } catch (err) {
      logger.warn("VOICE", "start failed", { error: String(err) });
    }
  };

  const stopListen = () => {
    recRef.current?.stop();
    setAssistant("idle");
  };

  const submit = () => {
    const v = text.trim();
    if (!v) return;
    setText("");
    void runTurn(v);
  };

  const busy = assistant === "thinking" || assistant === "executing";

  return (
    <div className="border-t border-border bg-card/95 px-3 py-3 backdrop-blur-sm md:px-4">
      <form
        className="mx-auto flex max-w-3xl items-end gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        {assistant === "speaking" ? (
          <Button type="button" variant="secondary" size="icon" aria-label={t(locale, "stop")} onClick={stopSpeaking}>
            <Square className="size-4" />
          </Button>
        ) : (
          <Button
            type="button"
            variant={assistant === "listening" ? "default" : "secondary"}
            size="icon"
            aria-label={assistant === "listening" ? t(locale, "stopListening") : t(locale, "holdToSpeak")}
            onClick={assistant === "listening" ? stopListen : startListen}
            disabled={busy}
          >
            <Mic className={cn("size-4", assistant === "listening" && "animate-pulse")} />
          </Button>
        )}
        <label className="sr-only" htmlFor="cold-input">
          {t(locale, "typePlaceholder")}
        </label>
        <input
          id="cold-input"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={t(locale, "typePlaceholder")}
          className="h-12 min-w-0 flex-1 rounded-xl border border-border bg-background px-4 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
          autoComplete="off"
        />
        <Button type="submit" size="icon" disabled={busy || !text.trim()} aria-label={t(locale, "send")}>
          <ArrowUp className="size-4" />
        </Button>
      </form>
    </div>
  );
}
