import type { ReactNode } from "react";

export function PageHeader({
  kicker,
  title,
  lead,
  actions,
}: {
  kicker?: string;
  title: string;
  lead?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div className="space-y-1">
        {kicker ? <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">{kicker}</p> : null}
        <h1 className="font-display text-3xl font-medium tracking-tight text-foreground">{title}</h1>
        {lead ? <p className="max-w-xl text-sm text-muted-foreground">{lead}</p> : null}
      </div>
      {actions}
    </header>
  );
}
