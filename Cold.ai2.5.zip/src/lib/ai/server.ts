import { createServerFn } from "@tanstack/react-start";

export type AssistPayload = {
  text: string;
  locale: string;
  context: string;
  memory: string;
  localHint?: string;
  mode: "orchestrate" | "chat" | "translate";
  targetLang?: string;
};

function extractJson(raw: string): Record<string, unknown> | null {
  const fenced = raw.match(/```json\s*([\s\S]*?)```/i);
  const src = fenced?.[1] ?? raw;
  const start = src.indexOf("{");
  const end = src.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(src.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

async function chatXai(
  messages: { role: "system" | "user" | "assistant"; content: string }[],
  maxTokens: number,
): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available" };
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      messages,
      temperature: 0.3,
      max_tokens: maxTokens,
    }),
  });
  if (!res.ok) return { ok: false, error: `xAI API error ${res.status}` };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return { ok: true, text: body.choices?.[0]?.message?.content ?? "" };
}

export const assistTurn = createServerFn({ method: "POST" })
  .inputValidator((input: AssistPayload) => input)
  .handler(async ({ data }) => {
    const langName =
      { uk: "Ukrainian", en: "English", pl: "Polish", de: "German" }[data.locale] ?? "Ukrainian";

    if (data.mode === "translate") {
      const result = await chatXai(
        [
          {
            role: "system",
            content: `Translate faithfully into ${data.targetLang || "English"}. Return only the translation.`,
          },
          { role: "user", content: data.text },
        ],
        400,
      );
      if (!result.ok) return result;
      return { ok: true as const, kind: "ai_response", reply: result.text, actions: [] as unknown[] };
    }

    if (data.mode === "chat") {
      const result = await chatXai(
        [
          {
            role: "system",
            content: `You are COLD, a personal operating assistant. Reply in ${langName}. Be concise, calm, and specific. Never invent device state. If a local action would be better, say so briefly.`,
          },
          {
            role: "user",
            content: `Memory:\n${data.memory || "(empty)"}\n\nContext:\n${data.context}\n\nUser: ${data.text}`,
          },
        ],
        700,
      );
      if (!result.ok) return result;
      return { ok: true as const, kind: "conversation", reply: result.text, actions: [] as unknown[] };
    }

    const result = await chatXai(
      [
        {
          role: "system",
          content: `You are COLD's orchestrator. Reply in ${langName} for the "reply" field. Return JSON only:
{"kind":"local_action|task_plan|web_task|system_task|automation|memory|conversation|clarification","reply":"...","question":null,"actions":[{"kind":"open_app|search_web|search_youtube|search_maps|navigate|timer_create|alarm_create|reminder_create|event_list|weather|translate|calculate|memory_save|ai_respond|volume_set|focus_mode|diagnostics_report","label":"...","args":{}}]}
Use actions only when they should actually run. Do not guess missing times, contacts, or delete targets — set kind to clarification and question.
Local hint: ${data.localHint || "none"}`,
        },
        {
          role: "user",
          content: `Memory:\n${data.memory || "(empty)"}\nContext:\n${data.context}\nUser: ${data.text}`,
        },
      ],
      800,
    );
    if (!result.ok) return result;
    const parsed = extractJson(result.text);
    if (!parsed) {
      return { ok: true as const, kind: "conversation", reply: result.text, actions: [] as unknown[] };
    }
    return {
      ok: true as const,
      kind: String(parsed.kind ?? "conversation"),
      reply: String(parsed.reply ?? result.text),
      question: parsed.question ? String(parsed.question) : undefined,
      actions: Array.isArray(parsed.actions) ? parsed.actions : [],
    };
  });

export const neuralSpeak = createServerFn({ method: "POST" })
  .inputValidator((input: { text: string }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "AI is not available" };
    const res = await fetch("https://api.x.ai/v1/tts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ text: data.text.slice(0, 500), voice_id: "eve" }),
    });
    if (!res.ok) return { ok: false as const, error: `TTS ${res.status}` };
    const buf = Buffer.from(await res.arrayBuffer());
    return { ok: true as const, audio: `data:audio/mpeg;base64,${buf.toString("base64")}` };
  });
