import { uid } from "../../core/id.ts";
import { includesNormalized } from "../../core/normalize.ts";
import type { MemoryCategory, MemoryItem } from "../../core/types.ts";

export function remember(
  items: MemoryItem[],
  value: string,
  category: MemoryCategory = "facts",
  title?: string,
): MemoryItem[] {
  const now = Date.now();
  const item: MemoryItem = {
    id: uid("mem"),
    category,
    title: title || value.slice(0, 80),
    value,
    createdAt: now,
    updatedAt: now,
  };
  return [item, ...items];
}

export function forget(items: MemoryItem[], query: string): { items: MemoryItem[]; removed: MemoryItem[] } {
  if (!query.trim()) return { items, removed: [] };
  const removed = items.filter((m) => includesNormalized(m.title, query) || includesNormalized(m.value, query));
  if (!removed.length) return { items, removed: [] };
  const ids = new Set(removed.map((r) => r.id));
  return { items: items.filter((m) => !ids.has(m.id)), removed };
}

export function listMemory(items: MemoryItem[], category?: MemoryCategory): MemoryItem[] {
  const rows = category ? items.filter((m) => m.category === category) : items;
  return [...rows].sort((a, b) => b.updatedAt - a.updatedAt);
}

export function summarizeMemory(items: MemoryItem[]): string {
  if (!items.length) return "";
  return items
    .slice(0, 12)
    .map((m) => `${m.category}: ${m.value}`)
    .join("\n");
}
