export function normalize(input: string): string {
  return input
    .toLowerCase()
    .replace(/[’`´]/g, "'")
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}%:./\s'-]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function stripDiacritics(input: string): string {
  return input.normalize("NFD").replace(/\p{M}/gu, "");
}

export function tokenize(input: string): string[] {
  const n = normalize(input);
  return n ? n.split(" ") : [];
}

export function includesNormalized(haystack: string, needle: string): boolean {
  return normalize(haystack).includes(normalize(needle));
}
