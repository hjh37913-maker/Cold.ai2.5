import { evaluateMath, looksLikeMath } from "../../core/calc.ts";
import { nextDateFromText, parseClock, parseDurationMs } from "../../core/datetime.ts";
import { uid } from "../../core/id.ts";
import { normalize } from "../../core/normalize.ts";
import { bestMatch } from "../../core/fuzzy.ts";
import type {
  ActionKind,
  AppEntry,
  Contact,
  Locale,
  OrchestratorKind,
  PlannedAction,
} from "../../core/types.ts";
import { APP_CATALOG } from "../apps/catalog.ts";

export interface IntentInput {
  text: string;
  locale: Locale;
  contacts: Contact[];
  apps?: AppEntry[];
  lastAppId?: string;
  lastIntent?: ActionKind;
  lastDurationMs?: number;
  lastPlace?: string;
}

export interface IntentResult {
  kind: OrchestratorKind;
  confidence: number;
  actions: PlannedAction[];
  planTitle?: string;
  reply?: string;
  question?: string;
  usedContext?: boolean;
}

function act(kind: ActionKind, label: string, args: Record<string, unknown> = {}, extra: Partial<PlannedAction> = {}): PlannedAction {
  return { id: uid("act"), kind, label, args, ...extra };
}

function splitCommands(text: string): string[] {
  const parts = text
    .split(/\s*(?:,|;| then | потім | potem | und dann | i | та | і | and )\s*/i)
    .map((p) => p.trim())
    .filter((p) => p.length > 1);
  return parts.length > 1 ? parts : [text.trim()];
}

const ROUTINE_PHRASES: { key: string; re: RegExp }[] = [
  { key: "good_morning", re: /добр(ого|ий)\s*ранк|good morning|dzień dobry|guten morgen|підготуй.*ранк/i },
  { key: "good_night", re: /на ніч|до сну|good night|prepare.*sleep|Schlaf|spać|режим сну|підготуй.*(сон|ніч)/i },
  { key: "work", re: /режим робот|work mode|tryb pracy|arbeitsmodus/i },
  { key: "study", re: /режим навчан|study mode|tryb nauki|lernmodus|підготуй.*школ|prepare.*school/i },
  { key: "gaming", re: /режим ігор|gaming mode|tryb gry/i },
  { key: "travel", re: /режим подорож|travel mode|tryb podróży/i },
  { key: "driving", re: /режим водін|driving mode|tryb jazdy|fahrmodus/i },
  { key: "focus", re: /режим фокус|focus mode|tryb skupienia|fokus/i },
  { key: "silent", re: /тихий режим|silent|nie przeszkadzać|nicht stören|не турбувати|dnd/i },
  { key: "home", re: /я (вдома|дома)|i'?m home|jestem w domu|ich bin zuhause|режим дім/i },
  { key: "leaving", re: /виходжу|leaving home|wychodzę|ich gehe/i },
];

function parseOne(text: string, input: IntentInput): IntentResult | null {
  const n = normalize(text);
  if (!n) return { kind: "clarification", confidence: 1, actions: [], question: "empty" };

  if (/^(стоп|stop|halt|quite|тиша|заткнись)$/i.test(n)) {
    return { kind: "local_action", confidence: 1, actions: [act("media_pause", "Stop")], reply: "ok" };
  }

  const memSave = n.match(/^(?:запам'?ятай|remember|zapamiętaj|merk dir)\s*(?:що\s*)?(.+)$/i) ||
    n.match(/^(?:збережи це|save this|speichere das)$/i);
  if (/запам'?ятай|remember|zapamiętaj|merk dir|збережи це|save this/.test(n)) {
    const value = n.replace(/^(запам'?ятай|remember|zapamiętaj|merk dir|збережи це|save this|speichere das)\s*(що\s*)?/i, "").trim();
    if (!value) {
      return { kind: "clarification", confidence: 0.9, actions: [], question: "memory_what" };
    }
    return {
      kind: "memory",
      confidence: 0.95,
      actions: [act("memory_save", "Save memory", { value, category: "facts" })],
    };
  }
  if (/^забудь|^forget |^zapomnij|^vergiss/.test(n)) {
    const value = n.replace(/^(забудь|forget|zapomnij|vergiss)\s*/i, "").trim();
    return {
      kind: "memory",
      confidence: 0.92,
      actions: [act("memory_forget", "Forget", { value })],
    };
  }
  if (/що ти пам'?ятаєш|what do you remember|co pamiętasz|was erinnerst|збережені налаштування|saved settings/.test(n)) {
    return { kind: "memory", confidence: 0.95, actions: [act("memory_list", "List memory")] };
  }

  for (const r of ROUTINE_PHRASES) {
    if (r.re.test(text)) {
      return {
        kind: "automation",
        confidence: 0.9,
        planTitle: r.key,
        actions: [act("routine_run", r.key, { routineId: r.key })],
      };
    }
  }

  if (looksLikeMath(n) || /скільки буде|how much is|policz|berechne|переведи \d|convert \d/.test(n)) {
    const result = evaluateMath(n);
    if (result.ok) {
      return {
        kind: "local_action",
        confidence: 0.96,
        actions: [act("calculate", "Calculate", { expression: text, value: result.value })],
        reply: result.value,
      };
    }
  }

  if (/переклади|translate|tłumacz|übersetze|як сказати/.test(n)) {
    const m = text.replace(/^(переклади|translate|tłumacz|übersetze)\s*/i, "").trim();
    const lang = n.match(/на\s+(українськ|англійськ|польськ|німецьк|english|ukrainian|polish|german|polski|deutsch)\w*/i);
    if (!m) {
      return { kind: "clarification", confidence: 0.88, actions: [], question: "translate_what" };
    }
    return {
      kind: "web_task",
      confidence: 0.9,
      actions: [
        act("translate", "Translate", {
          text: m,
          target: lang?.[1] ?? "en",
        }),
      ],
    };
  }

  if (/погод|weather|pogod|wetter/.test(n)) {
    const place = n.replace(/.*(?:в|у|in|we)\s+/, "").replace(/погод\w*|weather|pogod\w*|wetter/g, "").trim();
    return {
      kind: "web_task",
      confidence: 0.9,
      actions: [
        act("weather", "Weather", { place: place.length > 1 ? place : undefined }, { requiresPermission: "geolocation" }),
      ],
    };
  }

  if (/таймер|timer|minutnik/.test(n) && !/секундомір|stopwatch|stoper/.test(n)) {
    if (/скасуй|cancel|stop|wyłącz|ausschalten|список|list/.test(n) && /таймер|timer/.test(n)) {
      if (/список|list|покажи/.test(n)) return { kind: "local_action", confidence: 0.9, actions: [act("timer_list", "List timers")] };
      return { kind: "local_action", confidence: 0.88, actions: [act("timer_cancel", "Cancel timer")] };
    }
    const dur = parseDurationMs(n) ?? (input.lastDurationMs && /ще один|another|kolejny|noch einen/.test(n) ? input.lastDurationMs : null);
    const follow = /ще один|another|jeszcze jeden|noch einen/.test(n);
    if (!dur) {
      const nOnly = n.match(/(\d+)/);
      if (nOnly && (follow || input.lastIntent === "timer_create")) {
        const minutes = Number(nOnly[1]);
        return {
          kind: "local_action",
          confidence: 0.86,
          usedContext: true,
          actions: [act("timer_create", "Timer", { durationMs: minutes * 60_000, label: `${minutes} min` })],
        };
      }
      return { kind: "clarification", confidence: 0.9, actions: [], question: "timer_duration" };
    }
    return {
      kind: "local_action",
      confidence: 0.95,
      usedContext: follow,
      actions: [act("timer_create", "Timer", { durationMs: dur })],
    };
  }

  if (/секундомір|stopwatch|stoper|stoper/.test(n)) {
    if (/стоп|stop|pause|пауз/.test(n)) return { kind: "local_action", confidence: 0.93, actions: [act("stopwatch_stop", "Stop stopwatch")] };
    if (/скид|reset/.test(n)) return { kind: "local_action", confidence: 0.93, actions: [act("stopwatch_reset", "Reset stopwatch")] };
    return { kind: "local_action", confidence: 0.93, actions: [act("stopwatch_start", "Start stopwatch")] };
  }

  if (/будильник|alarm|wecker|budzik/.test(n)) {
    if (/список|list|покажи/.test(n)) return { kind: "local_action", confidence: 0.9, actions: [act("alarm_list", "List alarms")] };
    if (/скасуй|cancel|вимкни|delete|usuń/.test(n)) return { kind: "local_action", confidence: 0.88, actions: [act("alarm_cancel", "Cancel alarm")] };
    const clock = parseClock(n);
    if (!clock) {
      return { kind: "clarification", confidence: 0.92, actions: [], question: "alarm_time" };
    }
    return {
      kind: "local_action",
      confidence: 0.94,
      actions: [act("alarm_create", "Alarm", { hour: clock.hour, minute: clock.minute })],
    };
  }

  if (/нагадай|remind|przypomnij|erinnere/.test(n)) {
    const when = nextDateFromText(n);
    const title = n
      .replace(/нагадай( мені)?|remind me|przypomnij|erinnere mich/gi, "")
      .replace(/о \d+.*/i, "")
      .replace(/tomorrow|завтра|через .*|in \d+.*/gi, "")
      .trim();
    if (!when) {
      return { kind: "clarification", confidence: 0.9, actions: [], question: "reminder_when" };
    }
    if (!title || title.length < 2) {
      return {
        kind: "clarification",
        confidence: 0.9,
        actions: [],
        question: "reminder_what",
      };
    }
    return {
      kind: "local_action",
      confidence: 0.93,
      actions: [act("reminder_create", "Reminder", { title, at: when.getTime() })],
    };
  }

  if (/що в мене|what's on|what do i have|co mam|was habe ich|календар|calendar|зустріч/.test(n) && !/нагадай/.test(n)) {
    const when = /завтра|tomorrow|jutro|morgen/.test(n) ? "tomorrow" : /тижн|week/.test(n) ? "week" : "today";
    if (/створ|create|dodaj|neue/.test(n)) {
      const whenDate = nextDateFromText(n);
      const title = n.replace(/створи подію|create event|dodaj wydarzenie/gi, "").trim();
      if (!whenDate) return { kind: "clarification", confidence: 0.85, actions: [], question: "event_when" };
      return {
        kind: "local_action",
        confidence: 0.86,
        actions: [act("event_create", "Create event", { title: title || "Event", start: whenDate.getTime() })],
      };
    }
    return { kind: "local_action", confidence: 0.9, actions: [act("event_list", "List events", { range: when })] };
  }

  if (/гучн|volume|głośność|lautstärke/.test(n)) {
    const pct = n.match(/(\d+)\s*%/);
    const nOnly = n.match(/(\d+)/);
    const value = pct ? Number(pct[1]) : nOnly ? Number(nOnly[1]) : undefined;
    if (value === undefined) {
      return { kind: "clarification", confidence: 0.8, actions: [], question: "volume" };
    }
    return {
      kind: "system_task",
      confidence: 0.92,
      actions: [act("volume_set", "Volume", { percent: Math.max(0, Math.min(100, value)) })],
    };
  }

  if (/\bpause\b|пауза|зупини музик/.test(n)) {
    return { kind: "local_action", confidence: 0.9, actions: [act("media_pause", "Pause")] };
  }
  if (/\bplay\b|грай|відтвори|włącz muzykę/.test(n) && /музик|music|media|spotify|youtube/.test(n)) {
    return { kind: "local_action", confidence: 0.86, actions: [act("media_play", "Play")] };
  }
  if (/наступн|next track|następny|nächster/.test(n)) {
    return { kind: "local_action", confidence: 0.88, actions: [act("media_next", "Next")] };
  }
  if (/попередн|previous|poprzedni|vorheriger/.test(n)) {
    return { kind: "local_action", confidence: 0.88, actions: [act("media_prev", "Previous")] };
  }

  if (/ліхтар|flashlight|latarka|taschenlampe/.test(n)) {
    const on = !/вимк|off|wyłącz|aus/.test(n);
    return { kind: "system_task", confidence: 0.9, actions: [act("flashlight", "Flashlight", { on })] };
  }

  if (/камер|camera|aparat|zrób zdjęcie|зроби фото|take a (photo|picture)/.test(n)) {
    return {
      kind: "system_task",
      confidence: 0.9,
      actions: [act("camera_open", "Camera", {}, { requiresPermission: "camera" })],
    };
  }

  if (/перевір (телефон|пристрій)|check (phone|device)|diagnostics|діагностик|чому .*(повільн|slow)|що .*пам.?ят/.test(n)) {
    return { kind: "local_action", confidence: 0.92, actions: [act("diagnostics_report", "Diagnostics")] };
  }

  if (/що нового|show notifications|сповіщен|powiadomien|benachricht/i.test(n)) {
    return {
      kind: "local_action",
      confidence: 0.88,
      actions: [act("notification_list", "Notifications", { filter: /важлив|important|ważn/.test(n) ? "important" : "all" })],
    };
  }

  if (/фотограф|photos|gallery|галере/.test(n)) {
    const today = /сьогодні|today|dzisiaj|heute/.test(n);
    return {
      kind: "local_action",
      confidence: 0.86,
      actions: [act("gallery_recent", "Gallery", { today })],
    };
  }

  if (/файл|document|документ|останн(ій|ій) документ/.test(n)) {
    const q = n.replace(/знайди|find|open|відкрий|покажи/g, "").trim();
    return { kind: "local_action", confidence: 0.84, actions: [act("file_search", "Files", { query: q })] };
  }

  if (/подзвон|call |zadzwoń|anrufen/.test(n)) {
    const name = n.replace(/^(подзвон(и)?(ти)?|call|zadzwoń|ruf an|anrufen)\s*/i, "").replace(/^до\s+/i, "").trim();
    if (!name) return { kind: "clarification", confidence: 0.9, actions: [], question: "contact" };
    const match = bestMatch(name, input.contacts, (c) => c.name, 0.45);
    if (!match) {
      return {
        kind: "clarification",
        confidence: 0.7,
        actions: [act("contact_search", "Find contact", { query: name })],
        question: "contact_missing",
      };
    }
    if (match.matches.length > 1) {
      return {
        kind: "clarification",
        confidence: 0.95,
        actions: [],
        question: "contact_ambiguous",
        reply: match.matches.map((c) => c.name).join(", "),
      };
    }
    return {
      kind: "system_task",
      confidence: match.score,
      actions: [
        act(
          "call",
          `Call ${match.item.name}`,
          { contactId: match.item.id, name: match.item.name, phone: match.item.phone },
          { requiresConfirmation: true, requiresPermission: "contacts" },
        ),
      ],
    };
  }

  if (/sms|напиши|send (sms|message|text)|wyślij wiadomość/.test(n)) {
    const rest = text.replace(/^(напиши( sms)?|send (an )?(sms|message|text)|wyślij)\s*/i, "");
    return {
      kind: "system_task",
      confidence: 0.8,
      actions: [
        act("sms", "SMS", { text: rest }, { requiresConfirmation: true, requiresPermission: "contacts" }),
      ],
    };
  }

  if (/що я просив|what did i (ask|say)|wczoraj|yesterday|істор/.test(n)) {
    return { kind: "memory", confidence: 0.84, actions: [act("history_query", "History", { query: n })] };
  }

  if (/youtube|ютуб/.test(n) && /знайди|find|search|шукай|відео про/.test(n)) {
    const q = text.replace(/.*(youtube|ютуб)\s*/i, "").replace(/знайди|find|search|відео про|про/gi, "").trim();
    return {
      kind: "web_task",
      confidence: 0.9,
      usedContext: false,
      actions: [act("search_youtube", "YouTube search", { query: q || text })],
    };
  }

  if (input.lastAppId === "youtube" && /знайди|find|search|музик/.test(n) && !/google|гугл/.test(n)) {
    const q = n.replace(/знайди|find|search|музику?|на youtube/g, "").trim();
    return {
      kind: "web_task",
      confidence: 0.8,
      usedContext: true,
      actions: [act("search_youtube", "YouTube search", { query: q || n })],
    };
  }

  if (/карт|maps|маршрут|navigate|найближч|кафе|route/.test(n) && /відкрий|open|знайди|find|проклад|navigate|cafe|кав/.test(n)) {
    const q = text.replace(/відкрий карту|open maps|проклади маршрут|navigate/gi, "").trim() || input.lastPlace || "cafe";
    const nav = /маршрут|navigate|route/.test(n);
    return {
      kind: "web_task",
      confidence: 0.86,
      actions: [act(nav ? "navigate" : "search_maps", nav ? "Navigate" : "Maps", { query: q })],
    };
  }

  if (/пошукай|загугли|google|search the web|szukaj w/.test(n)) {
    const q = text.replace(/^(пошукай( в гуглі)?|загугли|google|search( the web)?( for)?|szukaj)\s*/i, "").trim();
    return { kind: "web_task", confidence: 0.88, actions: [act("search_web", "Web search", { query: q || text })] };
  }

  const open = n.match(/^(відкрий|запусти|open|otwórz|öffne|launch)\s+(.+)$/);
  if (open) {
    const target = open[2]!.trim();
    if (!target) return { kind: "clarification", confidence: 0.9, actions: [], question: "app" };
    if (/налаштуван|settings|ustawienia/.test(target)) {
      return { kind: "local_action", confidence: 0.95, actions: [act("settings_open", "Settings")] };
    }
    if (/^http/.test(target)) {
      return { kind: "web_task", confidence: 0.95, actions: [act("open_url", "Open URL", { url: target })] };
    }
    const apps = input.apps?.length ? input.apps : APP_CATALOG;
    const match = bestMatch(target, apps, (a) => a.names, 0.45);
    if (!match) {
      return {
        kind: "web_task",
        confidence: 0.55,
        actions: [act("search_web", "Search", { query: target })],
      };
    }
    return {
      kind: "local_action",
      confidence: match.score,
      actions: [act("open_app", `Open ${match.item.names[0]}`, { appId: match.item.id, url: match.item.url })],
    };
  }

  if (/info about|інформацію про|app info|дозволи застосунк/.test(n)) {
    const target = n.replace(/.*про\s+|info about|app info/g, "").trim();
    const match = bestMatch(target, APP_CATALOG, (a) => a.names, 0.4);
    if (match) {
      return {
        kind: "local_action",
        confidence: 0.8,
        actions: [act("open_app", "App info", { appId: match.item.id, info: true })],
      };
    }
  }

  if (/режим фокус|focus|не турбувати|do not disturb|silent/.test(n)) {
    const on = !/вимк|off|disable/.test(n);
    return { kind: "system_task", confidence: 0.88, actions: [act("focus_mode", "Focus", { on })] };
  }

  if (/^поясн|^explain|^why |^що таке|^what is|^how does|^як працю/.test(n) || n.split(" ").length > 8) {
    return { kind: "conversation", confidence: 0.4, actions: [act("ai_respond", "Answer", { prompt: text })] };
  }

  return null;
}

export function parseIntent(input: IntentInput): IntentResult {
  const text = input.text.trim();
  if (!text) {
    return { kind: "clarification", confidence: 1, actions: [], question: "empty" };
  }

  const parts = splitCommands(text);
  if (parts.length > 1) {
    const parsed = parts.map((p) => parseOne(p, input)).filter((x): x is IntentResult => Boolean(x && x.actions.length));
    if (parsed.length >= 2) {
      const actions = parsed.flatMap((p) => p.actions);
      return {
        kind: "task_plan",
        confidence: parsed.reduce((s, p) => s + p.confidence, 0) / parsed.length,
        actions,
        planTitle: text,
      };
    }
  }

  const single = parseOne(text, input);
  if (single) return single;

  return {
    kind: "conversation",
    confidence: 0.3,
    actions: [act("ai_respond", "Respond", { prompt: text })],
  };
}

export function questionKeyToPrompt(key: string, locale: Locale): string {
  const table: Record<string, Record<string, string>> = {
    uk: {
      empty: "Я нічого не почув. Скажіть ще раз.",
      timer_duration: "На скільки поставити таймер?",
      alarm_time: "На який час поставити будильник?",
      reminder_what: "Про що нагадати?",
      reminder_when: "Коли нагадати?",
      translate_what: "Що перекласти і якою мовою?",
      contact: "Кому зателефонувати?",
      contact_ambiguous: "Якого саме? Є кілька збігів.",
      contact_missing: "Такого контакту немає. Додати?",
      app: "Який застосунок відкрити?",
      volume: "На скільки відсотків поставити гучність?",
      memory_what: "Що саме запам'ятати?",
      event_when: "Коли створити подію?",
    },
    en: {
      empty: "I didn't catch that. Say it again.",
      timer_duration: "How long should the timer be?",
      alarm_time: "What time should I set the alarm?",
      reminder_what: "What should I remind you about?",
      reminder_when: "When should I remind you?",
      translate_what: "What should I translate, and into which language?",
      contact: "Who should I call?",
      contact_ambiguous: "Which one? There are several matches.",
      contact_missing: "I don't have that contact. Add them?",
      app: "Which app should I open?",
      volume: "What volume percent?",
      memory_what: "What should I remember?",
      event_when: "When should I create the event?",
    },
  };
  const loc = table[locale] ?? table.en!;
  return loc[key] ?? table.en![key] ?? key;
}
