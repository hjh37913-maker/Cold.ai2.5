import { createFileRoute, Link } from "@tanstack/react-router";
import {
  AppWindow,
  Bell,
  Brain,
  CalendarDays,
  Cpu,
  Folder,
  Image,
  Lock,
  MessageCircle,
  Music,
  Shield,
  Sparkles,
  Sun,
  Timer,
  Watch,
  Workflow,
} from "lucide-react";
import { PageHeader } from "@/components/cold/page-header";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";

export const Route = createFileRoute("/center")({ component: CenterPage });

function CenterPage() {
  const locale = useColdStore((s) => s.settings.locale);
  const groups = [
    {
      title: t(locale, "catSystem"),
      items: [
        { to: "/diagnostics", label: t(locale, "diagnosticsTitle"), icon: Cpu },
        { to: "/privacy", label: t(locale, "privacyTitle"), icon: Shield },
        { to: "/settings", label: t(locale, "settingsTitle"), icon: Watch },
      ],
    },
    {
      title: t(locale, "catApps"),
      items: [{ to: "/apps", label: t(locale, "appsTitle"), icon: AppWindow }],
    },
    {
      title: t(locale, "catCommunication"),
      items: [{ to: "/contacts", label: t(locale, "contactsTitle"), icon: MessageCircle }],
    },
    {
      title: t(locale, "catMedia"),
      items: [
        { to: "/media", label: t(locale, "mediaTitle"), icon: Music },
        { to: "/files?tab=gallery", label: t(locale, "galleryTitle"), icon: Image },
      ],
    },
    {
      title: t(locale, "catProductivity"),
      items: [
        { to: "/productivity", label: t(locale, "calendarTitle"), icon: CalendarDays },
        { to: "/productivity?tab=timers", label: t(locale, "timersTitle"), icon: Timer },
        { to: "/files", label: t(locale, "filesTitle"), icon: Folder },
      ],
    },
    {
      title: t(locale, "catAutomation"),
      items: [{ to: "/automation", label: t(locale, "automations"), icon: Workflow }],
    },
    {
      title: t(locale, "catAi"),
      items: [
        { to: "/chat", label: t(locale, "navChat"), icon: Sparkles },
        { to: "/weather", label: t(locale, "weatherTitle"), icon: Sun },
        { to: "/task", label: t(locale, "taskTitle"), icon: Brain },
      ],
    },
    {
      title: t(locale, "catMemory"),
      items: [{ to: "/memory", label: t(locale, "memoryTitle"), icon: Brain }],
    },
    {
      title: t(locale, "catSecurity"),
      items: [{ to: "/privacy", label: t(locale, "setSecurity"), icon: Lock }],
    },
    {
      title: t(locale, "catDiagnostics"),
      items: [
        { to: "/diagnostics", label: t(locale, "checkPhone"), icon: Cpu },
        { to: "/notifications", label: t(locale, "notificationsTitle"), icon: Bell },
      ],
    },
  ];

  return (
    <main className="mx-auto flex w-full max-w-4xl flex-col gap-8 px-5 py-8">
      <PageHeader title={t(locale, "centerTitle")} lead={t(locale, "centerLead")} />
      {groups.map((g) => (
        <section key={g.title} className="space-y-3">
          <h2 className="text-sm font-medium text-muted-foreground">{g.title}</h2>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {g.items.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className="flex min-h-16 items-center gap-3 rounded-2xl border border-border bg-card px-4 text-sm font-medium hover:bg-secondary"
                >
                  <Icon className="size-4 shrink-0" />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </section>
      ))}
    </main>
  );
}
