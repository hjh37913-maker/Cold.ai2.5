import { createFileRoute } from "@tanstack/react-router";
import { Pause, Play, SkipBack, SkipForward } from "lucide-react";
import { useRef } from "react";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";

export const Route = createFileRoute("/media")({ component: MediaPage });

function MediaPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const volume = useColdStore((s) => s.mediaVolume);
  const ref = useRef<HTMLAudioElement>(null);

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "mediaTitle")} lead={t(loc, "browserLimit")} />
      <section className="rounded-2xl border border-border bg-card p-5">
        <audio ref={ref} className="w-full" controls src="" />
        <p className="mt-3 text-sm text-muted-foreground">
          {t(loc, "volumeSet", { n: Math.round(volume * 100) })}
        </p>
        <Slider
          className="mt-4"
          min={0}
          max={1}
          step={0.05}
          value={[volume]}
          onValueChange={(v) => {
            const n = v[0] ?? 0.7;
            useColdStore.setState({ mediaVolume: n });
            if (ref.current) ref.current.volume = n;
          }}
        />
        <div className="mt-4 flex gap-2">
          <Button variant="outline" size="icon" aria-label="previous" onClick={() => void useColdStore.getState().runTurn("previous")}>
            <SkipBack className="size-4" />
          </Button>
          <Button
            size="icon"
            onClick={() => {
              const el = ref.current;
              if (!el) return;
              if (el.paused) void el.play().catch(() => undefined);
              else el.pause();
            }}
          >
            <Play className="size-4" />
          </Button>
          <Button variant="outline" size="icon" aria-label="pause" onClick={() => ref.current?.pause()}>
            <Pause className="size-4" />
          </Button>
          <Button variant="outline" size="icon" aria-label="next" onClick={() => void useColdStore.getState().runTurn("next")}>
            <SkipForward className="size-4" />
          </Button>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => window.open("https://open.spotify.com", "_blank", "noopener")}>
            Spotify
          </Button>
          <Button variant="outline" onClick={() => window.open("https://www.youtube.com", "_blank", "noopener")}>
            YouTube
          </Button>
        </div>
      </section>
    </main>
  );
}
