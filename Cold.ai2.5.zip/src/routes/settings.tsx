import type { ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { LOCALES, t } from "@/core/i18n";
import { APP_VERSION, useColdStore } from "@/core/store";
import type { Locale, ThemeMode } from "@/core/types";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const s = useColdStore();
  const loc = s.settings.locale;

  const download = () => {
    const blob = new Blob([s.exportData()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cold-ai-data.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-8 px-5 py-8">
      <PageHeader title={t(loc, "settingsTitle")} />

      <Section title={t(loc, "setGeneral")}>
        <Field label={t(loc, "language")}>
          <select
            className="h-11 rounded-md border border-border bg-card px-3 text-sm"
            value={loc}
            onChange={(e) => {
              const locale = e.target.value as Locale;
              s.patchSettings({ locale });
              s.patchVoice({ locale });
            }}
          >
            {LOCALES.map((l) => (
              <option key={l.id} value={l.id}>
                {l.label}
              </option>
            ))}
          </select>
        </Field>
      </Section>

      <Section title={t(loc, "setAppearance")}>
        <Field label={t(loc, "theme")}>
          <div className="flex gap-2">
            {(["system", "light", "dark"] as ThemeMode[]).map((mode) => (
              <Button
                key={mode}
                variant={s.settings.theme === mode ? "default" : "outline"}
                onClick={() => s.patchSettings({ theme: mode })}
              >
                {t(loc, mode === "system" ? "themeSystem" : mode === "light" ? "themeLight" : "themeDark")}
              </Button>
            ))}
          </div>
        </Field>
        <Row label={t(loc, "largeText")} checked={s.settings.largeText} onChange={(v) => s.patchSettings({ largeText: v })} />
        <Row label={t(loc, "reducedMotion")} checked={s.settings.reducedMotion} onChange={(v) => s.patchSettings({ reducedMotion: v })} />
      </Section>

      <Section title={t(loc, "setVoice")}>
        <Row label={t(loc, "tts")} checked={s.voice.ttsEnabled} onChange={(v) => s.patchVoice({ ttsEnabled: v })} />
        <Row label={t(loc, "autoListen")} checked={s.voice.autoListen} onChange={(v) => s.patchVoice({ autoListen: v })} />
        <Row label={t(loc, "wakeWord")} checked={s.voice.wakeWord} onChange={(v) => s.patchVoice({ wakeWord: v })} />
        <Field label={t(loc, "wakePhrase")}>
          <Input value={s.voice.wakePhrase} onChange={(e) => s.patchVoice({ wakePhrase: e.target.value })} />
        </Field>
        <Field label={t(loc, "voiceRate")}>
          <Slider min={0.6} max={1.4} step={0.05} value={[s.voice.rate]} onValueChange={(v) => s.patchVoice({ rate: v[0] ?? 1 })} />
        </Field>
        <Field label={t(loc, "mediaVolume")}>
          <Slider min={0} max={1} step={0.05} value={[s.mediaVolume]} onValueChange={(v) => useColdStore.setState({ mediaVolume: v[0] ?? 0.7 })} />
        </Field>
      </Section>

      <Section title={t(loc, "setAi")}>
        <Field label={t(loc, "aiProvider")}>
          <p className="text-sm text-muted-foreground">xAI (Grok) · OpenAI-compatible later · local later</p>
        </Field>
        <Field label={t(loc, "aiModel")}>
          <p className="text-sm">{s.ai.model}</p>
        </Field>
        <Row label={t(loc, "useAiLocal")} checked={s.ai.useForLocalCommands} onChange={(v) => s.patchAi({ useForLocalCommands: v })} />
      </Section>

      <Section title={t(loc, "setSecurity")}>
        <Row label={t(loc, "confirmSensitive")} checked={s.settings.confirmSensitive} onChange={(v) => s.patchSettings({ confirmSensitive: v })} />
      </Section>

      <Section title={t(loc, "setPerformance")}>
        <Row label={t(loc, "performanceMode")} checked={s.settings.performanceMode} onChange={(v) => s.patchSettings({ performanceMode: v })} />
      </Section>

      <Section title={t(loc, "setPrivacy")}>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={download}>
            {t(loc, "exportData")}
          </Button>
          <Button variant="outline" onClick={() => s.clearMemory()}>
            {t(loc, "forgetAll")}
          </Button>
        </div>
      </Section>

      <Section title={t(loc, "setAbout")}>
        <p className="text-sm leading-relaxed text-muted-foreground">{t(loc, "aboutBody")}</p>
        <p className="mt-3 text-sm">
          {t(loc, "version")} {APP_VERSION}
        </p>
        <p className="mt-4 text-sm text-muted-foreground">{t(loc, "limitationBody")}</p>
      </Section>
    </main>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-4 rounded-2xl border border-border bg-card p-5">
      <h2 className="font-display text-lg">{title}</h2>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function Row({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex min-h-11 items-center justify-between gap-3">
      <Label>{label}</Label>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
