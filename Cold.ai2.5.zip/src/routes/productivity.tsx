import { createFileRoute, useSearch } from "@tanstack/react-router";
import { useState } from "react";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatDateTime, formatDuration } from "@/core/datetime";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";

export const Route = createFileRoute("/productivity")({
  validateSearch: (s: Record<string, unknown>) => ({ tab: typeof s.tab === "string" ? s.tab : "calendar" }),
  component: ProductivityPage,
});

function ProductivityPage() {
  const loc = useColdStore((s) => s.settings.locale);
  const search = useSearch({ from: "/productivity" });
  const events = useColdStore((s) => s.events);
  const reminders = useColdStore((s) => s.reminders);
  const alarms = useColdStore((s) => s.alarms);
  const timers = useColdStore((s) => s.timers);
  const stopwatch = useColdStore((s) => s.stopwatch);
  const addEvent = useColdStore((s) => s.addEvent);
  const addReminder = useColdStore((s) => s.addReminder);
  const addAlarm = useColdStore((s) => s.addAlarm);
  const addTimer = useColdStore((s) => s.addTimer);
  const locTag = loc === "uk" ? "uk-UA" : loc === "pl" ? "pl-PL" : loc === "de" ? "de-DE" : "en-US";

  const [title, setTitle] = useState("");
  const [when, setWhen] = useState("");

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader title={t(loc, "catProductivity")} />
      <Tabs defaultValue={search.tab}>
        <TabsList className="flex flex-wrap">
          <TabsTrigger value="calendar">{t(loc, "calendarTitle")}</TabsTrigger>
          <TabsTrigger value="reminders">{t(loc, "remindersTitle")}</TabsTrigger>
          <TabsTrigger value="alarms">{t(loc, "alarmsTitle")}</TabsTrigger>
          <TabsTrigger value="timers">{t(loc, "timersTitle")}</TabsTrigger>
        </TabsList>
        <TabsContent value="calendar" className="mt-4 space-y-3">
          <form
            className="flex flex-col gap-2 sm:flex-row"
            onSubmit={(e) => {
              e.preventDefault();
              const start = when ? new Date(when).getTime() : Date.now() + 3600000;
              if (!title.trim()) return;
              addEvent({ title: title.trim(), start, end: start + 3600000 });
              setTitle("");
            }}
          >
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t(loc, "create")} />
            <Input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} />
            <Button type="submit">{t(loc, "save")}</Button>
          </form>
          {!events.length ? (
            <EmptyState title={t(loc, "emptyEvents")} />
          ) : (
            events.map((ev) => (
              <div key={ev.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3 text-sm">
                <span>{ev.title}</span>
                <span className="text-muted-foreground">{formatDateTime(ev.start, locTag)}</span>
              </div>
            ))
          )}
        </TabsContent>
        <TabsContent value="reminders" className="mt-4 space-y-3">
          <form
            className="flex flex-col gap-2 sm:flex-row"
            onSubmit={(e) => {
              e.preventDefault();
              const at = when ? new Date(when).getTime() : Date.now() + 30 * 60000;
              if (!title.trim()) return;
              addReminder(title.trim(), at);
              setTitle("");
            }}
          >
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t(loc, "remindersTitle")} />
            <Input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} />
            <Button type="submit">{t(loc, "save")}</Button>
          </form>
          {!reminders.length ? (
            <EmptyState title={t(loc, "emptyReminders")} />
          ) : (
            reminders.map((r) => (
              <div key={r.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3 text-sm">
                <span className={r.done ? "text-muted-foreground line-through" : ""}>{r.title}</span>
                <Button size="sm" variant="ghost" onClick={() => useColdStore.getState().toggleReminder(r.id)}>
                  {t(loc, "done")}
                </Button>
              </div>
            ))
          )}
        </TabsContent>
        <TabsContent value="alarms" className="mt-4 space-y-3">
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const [h, m] = (when || "07:00").split(":").map(Number);
              addAlarm(h || 7, m || 0);
            }}
          >
            <Input type="time" value={when} onChange={(e) => setWhen(e.target.value)} />
            <Button type="submit">{t(loc, "create")}</Button>
          </form>
          {!alarms.length ? (
            <EmptyState title={t(loc, "emptyAlarms")} />
          ) : (
            alarms.map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3">
                <p className="font-display text-2xl tabular-nums">
                  {String(a.hour).padStart(2, "0")}:{String(a.minute).padStart(2, "0")}
                </p>
                <Switch checked={a.enabled} onCheckedChange={() => useColdStore.getState().toggleAlarm(a.id)} />
              </div>
            ))
          )}
        </TabsContent>
        <TabsContent value="timers" className="mt-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            {[5, 10, 15, 25, 45].map((m) => (
              <Button key={m} variant="outline" onClick={() => addTimer(m * 60000, `${m} min`)}>
                {m} min
              </Button>
            ))}
          </div>
          {!timers.length ? (
            <EmptyState title={t(loc, "emptyTimers")} />
          ) : (
            timers.map((tm) => (
              <div key={tm.id} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3">
                <div>
                  <p className="text-sm">{tm.label}</p>
                  <p className="font-display text-2xl tabular-nums">{formatDuration(tm.remainingMs)}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => useColdStore.getState().toggleTimer(tm.id)}>
                    {tm.running ? t(loc, "stop") : t(loc, "continue")}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => useColdStore.getState().removeTimer(tm.id)}>
                    {t(loc, "delete")}
                  </Button>
                </div>
              </div>
            ))
          )}
          <div className="rounded-xl border border-border bg-card px-4 py-4">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Stopwatch</p>
            <p className="font-display text-3xl tabular-nums">
              {formatDuration(
                stopwatch.running && stopwatch.startedAt
                  ? stopwatch.elapsedMs + (Date.now() - stopwatch.startedAt)
                  : stopwatch.elapsedMs,
              )}
            </p>
            <div className="mt-3 flex gap-2">
              <Button onClick={() => useColdStore.getState().toggleStopwatch()}>
                {stopwatch.running ? t(loc, "stop") : t(loc, "run")}
              </Button>
              <Button variant="outline" onClick={() => useColdStore.getState().resetStopwatch()}>
                Reset
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </main>
  );
}
