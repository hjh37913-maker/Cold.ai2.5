import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { EmptyState } from "@/components/cold/empty-state";
import { PageHeader } from "@/components/cold/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { t } from "@/core/i18n";
import { useColdStore } from "@/core/store";
import { remember, forget } from "@/engines/memory/engine";

export const Route = createFileRoute("/memory")({ component: MemoryPage });

function MemoryPage() {
  const locale = useColdStore((s) => s.settings.locale);
  const memory = useColdStore((s) => s.memory);
  const [value, setValue] = useState("");

  return (
    <main className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-5 py-8">
      <PageHeader
        title={t(locale, "memoryTitle")}
        lead={t(locale, "emptyMemoryHint")}
        actions={
          <Button variant="outline" onClick={() => useColdStore.getState().clearMemory()}>
            {t(locale, "forgetAll")}
          </Button>
        }
      />
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!value.trim()) return;
          useColdStore.setState({ memory: remember(useColdStore.getState().memory, value.trim()) });
          setValue("");
        }}
      >
        <Input value={value} onChange={(e) => setValue(e.target.value)} placeholder={t(locale, "emptyMemoryHint")} />
        <Button type="submit">{t(locale, "save")}</Button>
      </form>
      {!memory.length ? (
        <EmptyState title={t(locale, "emptyMemory")} hint={t(locale, "emptyMemoryHint")} />
      ) : (
        <ul className="space-y-2">
          {memory.map((m) => (
            <li key={m.id} className="flex items-start justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">{m.category}</p>
                <p className="mt-1 text-sm">{m.value}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => useColdStore.setState({ memory: forget(useColdStore.getState().memory, m.value).items })}
              >
                {t(locale, "delete")}
              </Button>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
