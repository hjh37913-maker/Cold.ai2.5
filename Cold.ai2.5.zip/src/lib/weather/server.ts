import { createServerFn } from "@tanstack/react-start";

const WMO: Record<number, { uk: string; en: string }> = {
  0: { uk: "ясно", en: "clear" },
  1: { uk: "переважно ясно", en: "mainly clear" },
  2: { uk: "хмарно з проясненнями", en: "partly cloudy" },
  3: { uk: "хмарно", en: "overcast" },
  45: { uk: "туман", en: "fog" },
  51: { uk: "мряка", en: "drizzle" },
  61: { uk: "дощ", en: "rain" },
  71: { uk: "сніг", en: "snow" },
  80: { uk: "зливи", en: "rain showers" },
  95: { uk: "гроза", en: "thunderstorm" },
};

export const fetchWeather = createServerFn({ method: "POST" })
  .inputValidator((input: { lat?: number; lon?: number; place?: string; locale: string }) => input)
  .handler(async ({ data }) => {
    let lat = data.lat;
    let lon = data.lon;
    let placeName = data.place?.trim() || "";

    if ((!lat || !lon) && placeName) {
      const geo = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(placeName)}&count=1&language=${data.locale}`,
      );
      if (!geo.ok) return { ok: false as const, error: "geocode" };
      const gj = (await geo.json()) as { results?: { latitude: number; longitude: number; name: string; country: string }[] };
      const hit = gj.results?.[0];
      if (!hit) return { ok: false as const, error: "place" };
      lat = hit.latitude;
      lon = hit.longitude;
      placeName = `${hit.name}, ${hit.country}`;
    }

    if (lat === undefined || lon === undefined) {
      return { ok: false as const, error: "location" };
    }

    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=3&timezone=auto`;
    const res = await fetch(url);
    if (!res.ok) return { ok: false as const, error: "weather" };
    const body = (await res.json()) as {
      current?: {
        temperature_2m: number;
        weather_code: number;
        wind_speed_10m: number;
        relative_humidity_2m: number;
      };
      daily?: { time: string[]; temperature_2m_max: number[]; temperature_2m_min: number[]; weather_code: number[] };
    };
    const cur = body.current;
    if (!cur) return { ok: false as const, error: "weather" };
    const code = WMO[cur.weather_code] ?? WMO[Math.floor(cur.weather_code / 10) * 10] ?? { uk: "умови змінні", en: "mixed" };
    const label = data.locale === "uk" ? code.uk : code.en;
    const summary =
      data.locale === "uk"
        ? `${placeName || "Зараз"}: ${Math.round(cur.temperature_2m)}°, ${label}. Вітер ${Math.round(cur.wind_speed_10m)} км/год, вологість ${Math.round(cur.relative_humidity_2m)}%.`
        : `${placeName || "Now"}: ${Math.round(cur.temperature_2m)}°, ${label}. Wind ${Math.round(cur.wind_speed_10m)} km/h, humidity ${Math.round(cur.relative_humidity_2m)}%.`;
    return {
      ok: true as const,
      summary,
      place: placeName,
      temp: cur.temperature_2m,
      code: cur.weather_code,
      wind: cur.wind_speed_10m,
      humidity: cur.relative_humidity_2m,
      daily: (body.daily?.time ?? []).map((day, i) => ({
        day,
        max: body.daily!.temperature_2m_max[i]!,
        min: body.daily!.temperature_2m_min[i]!,
        code: body.daily!.weather_code[i]!,
      })),
    };
  });
