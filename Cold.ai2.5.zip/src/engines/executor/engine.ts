import { APP_CATALOG } from "../apps/catalog.ts";
import { forget, listMemory, remember } from "../memory/engine.ts";
import { endOfDay, formatDateTime, formatDuration, nextAlarmAt, startOfDay } from "../../core/datetime.ts";
import { uid } from "../../core/id.ts";
import { includesNormalized } from "../../core/normalize.ts";
import { logger } from "../../core/logger.ts";
import { t } from "../../core/i18n.ts";
import type {
  Alarm,
  AppNotification,
  CalendarEvent,
  IndexedFile,
  Locale,
  PermissionId,
  PlannedAction,
  Reminder,
  TimerItem,
} from "../../core/types.ts";

export interface ExecutorState {
  locale: Locale;
  mediaVolume: number;
  focusMode: boolean;
  flashlightOn: boolean;
  contacts: { id: string; name: string; phone?: string; email?: string }[];
  events: CalendarEvent[];
  reminders: Reminder[];
  alarms: Alarm[];
  timers: TimerItem[];
  memory: { id: string; category: never; title: string; value: string; createdAt: number; updatedAt: number }[] | ExecutorState["memory"];
  files: IndexedFile[];
  notifications: AppNotification[];
  history: { id: string; at: number; type: string; title: string; detail: string; ok: boolean }[];
}

export interface ExecResult {
  ok: boolean;
  message: string;
  patch?: Record<string, unknown>;
  openUrl?: string;
  navigate?: string;
  needsPermission?: PermissionId;
  speak?: string;
}

function notify(
  source: string,
  title: string,
  body: string,
  important = false,
): AppNotification {
  return {
    id: uid("ntf"),
    title,
    body,
    source,
    at: Date.now(),
    important,
    read: false,
    category: important ? "reminder" : "system",
  };
}

export function executeAction(
  action: PlannedAction,
  state: {
    locale: Locale;
    mediaVolume: number;
    focusMode: boolean;
    flashlightOn: boolean;
    contacts: { id: string; name: string; phone?: string; email?: string }[];
    events: CalendarEvent[];
    reminders: Reminder[];
    alarms: Alarm[];
    timers: TimerItem[];
    memory: Parameters<typeof remember>[0];
    files: IndexedFile[];
    notifications: AppNotification[];
    stopwatch: { running: boolean; elapsedMs: number; startedAt?: number };
    lastCommand: string;
    history: { id: string; at: number; type: "command" | "task" | "error" | "automation" | "conversation"; title: string; detail: string; ok: boolean }[];
    online: boolean;
  },
  extras?: { weatherSummary?: string; translation?: string; aiReply?: string },
): ExecResult {
  const loc = state.locale;
  const args = action.args;
  const kind = action.kind;

  try {
    switch (kind) {
      case "open_app": {
        const id = String(args.appId ?? "");
        const app = APP_CATALOG.find((a) => a.id === id);
        if (!app) return { ok: false, message: t(loc, "appNotFound") };
        if (app.url.startsWith("/")) return { ok: true, message: t(loc, "success"), navigate: app.url };
        return { ok: true, message: t(loc, "success"), openUrl: app.url };
      }
      case "open_url":
        return { ok: true, message: t(loc, "success"), openUrl: String(args.url ?? "") };
      case "search_web": {
        const q = encodeURIComponent(String(args.query ?? ""));
        return { ok: true, message: t(loc, "success"), openUrl: `https://www.google.com/search?q=${q}` };
      }
      case "search_youtube": {
        const q = encodeURIComponent(String(args.query ?? ""));
        return { ok: true, message: t(loc, "success"), openUrl: `https://www.youtube.com/results?search_query=${q}` };
      }
      case "search_maps":
      case "navigate": {
        const q = encodeURIComponent(String(args.query ?? ""));
        const url =
          kind === "navigate"
            ? `https://www.google.com/maps/dir/?api=1&destination=${q}`
            : `https://www.google.com/maps/search/?api=1&query=${q}`;
        return { ok: true, message: t(loc, "success"), openUrl: url };
      }
      case "call": {
        const phone = String(args.phone ?? "");
        const name = String(args.name ?? "");
        if (!phone) return { ok: false, message: t(loc, "askWhichContact") };
        return { ok: true, message: t(loc, "success"), openUrl: `tel:${phone}`, speak: `${t(loc, "confirmCall")} ${name}` };
      }
      case "sms": {
        const phone = String(args.phone ?? "");
        const body = encodeURIComponent(String(args.text ?? args.body ?? ""));
        if (!phone) return { ok: false, message: t(loc, "askWhichContact") };
        return { ok: true, message: t(loc, "success"), openUrl: `sms:${phone}?body=${body}` };
      }
      case "email": {
        const email = String(args.email ?? "");
        return { ok: true, message: t(loc, "success"), openUrl: `mailto:${email}` };
      }
      case "timer_create": {
        const durationMs = Number(args.durationMs ?? 0);
        if (!durationMs || durationMs < 1000) return { ok: false, message: t(loc, "invalidTimer") };
        const timer: TimerItem = {
          id: uid("tmr"),
          label: String(args.label ?? formatDuration(durationMs)),
          durationMs,
          remainingMs: durationMs,
          running: true,
          createdAt: Date.now(),
          endsAt: Date.now() + durationMs,
        };
        return {
          ok: true,
          message: loc === "uk" ? `Таймер ${formatDuration(durationMs)}.` : `Timer ${formatDuration(durationMs)}.`,
          patch: { timers: [timer, ...state.timers] },
        };
      }
      case "timer_list": {
        if (!state.timers.length) return { ok: true, message: t(loc, "emptyTimers") };
        const msg = state.timers.map((x) => `${x.label} ${formatDuration(x.remainingMs)}`).join("; ");
        return { ok: true, message: msg };
      }
      case "timer_cancel": {
        return { ok: true, message: t(loc, "cancelled"), patch: { timers: [] } };
      }
      case "stopwatch_start":
        return {
          ok: true,
          message: t(loc, "success"),
          patch: { stopwatch: { running: true, elapsedMs: state.stopwatch.elapsedMs, startedAt: Date.now() } },
        };
      case "stopwatch_stop": {
        const elapsed = state.stopwatch.running && state.stopwatch.startedAt
          ? state.stopwatch.elapsedMs + (Date.now() - state.stopwatch.startedAt)
          : state.stopwatch.elapsedMs;
        return { ok: true, message: formatDuration(elapsed), patch: { stopwatch: { running: false, elapsedMs: elapsed } } };
      }
      case "stopwatch_reset":
        return { ok: true, message: t(loc, "success"), patch: { stopwatch: { running: false, elapsedMs: 0 } } };
      case "alarm_create": {
        const hour = Number(args.hour);
        const minute = Number(args.minute ?? 0);
        if (!Number.isFinite(hour)) return { ok: false, message: t(loc, "askAlarmTime") };
        const alarm: Alarm = {
          id: uid("alm"),
          label: String(args.label ?? `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`),
          hour,
          minute,
          enabled: true,
          days: [],
          nextAt: nextAlarmAt(hour, minute),
        };
        const hh = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
        const msg =
          loc === "uk"
            ? `Будильник на ${hh}. Якщо потрібно інший час — скажіть.`
            : `Alarm set for ${hh}. Say if you need a different time.`;
        return { ok: true, message: msg, patch: { alarms: [alarm, ...state.alarms] } };
      }
      case "alarm_list": {
        if (!state.alarms.length) return { ok: true, message: t(loc, "emptyAlarms") };
        return {
          ok: true,
          message: state.alarms.map((a) => `${String(a.hour).padStart(2, "0")}:${String(a.minute).padStart(2, "0")}`).join(", "),
        };
      }
      case "alarm_cancel":
        return { ok: true, message: t(loc, "cancelled"), patch: { alarms: state.alarms.map((a) => ({ ...a, enabled: false })) } };
      case "reminder_create": {
        const title = String(args.title ?? "").trim();
        const at = Number(args.at ?? 0);
        if (!title) return { ok: false, message: t(loc, "askReminderWhat") };
        if (!at) return { ok: false, message: t(loc, "askReminderWhen") };
        const rem: Reminder = { id: uid("rem"), title, at, done: false, fired: false };
        return {
          ok: true,
          message: `${t(loc, "success")} ${formatDateTime(at, loc === "uk" ? "uk-UA" : "en-US")}`,
          patch: { reminders: [rem, ...state.reminders] },
        };
      }
      case "reminder_list": {
        const upcoming = state.reminders.filter((r) => !r.done);
        if (!upcoming.length) return { ok: true, message: t(loc, "emptyReminders") };
        return { ok: true, message: upcoming.map((r) => r.title).join("; ") };
      }
      case "reminder_cancel":
        return { ok: true, message: t(loc, "cancelled"), patch: { reminders: state.reminders.map((r) => ({ ...r, done: true })) } };
      case "event_create": {
        const title = String(args.title ?? "Event");
        const start = Number(args.start ?? 0);
        if (!start) return { ok: false, message: t(loc, "invalidDate") };
        const ev: CalendarEvent = {
          id: uid("evt"),
          title,
          start,
          end: start + 60 * 60 * 1000,
        };
        return { ok: true, message: t(loc, "added"), patch: { events: [ev, ...state.events] } };
      }
      case "event_list": {
        const range = String(args.range ?? "today");
        const now = Date.now();
        let from = startOfDay(now);
        let to = endOfDay(now);
        if (range === "tomorrow") {
          from = startOfDay(now + 86400000);
          to = endOfDay(now + 86400000);
        }
        if (range === "week") to = endOfDay(now + 6 * 86400000);
        const hits = state.events.filter((e) => e.start >= from && e.start <= to).sort((a, b) => a.start - b.start);
        if (!hits.length) return { ok: true, message: t(loc, "emptyEvents") };
        const locTag = loc === "uk" ? "uk-UA" : "en-US";
        return { ok: true, message: hits.map((e) => `${e.title} · ${formatDateTime(e.start, locTag)}`).join("; ") };
      }
      case "event_delete": {
        const q = String(args.query ?? args.title ?? "");
        const next = state.events.filter((e) => !includesNormalized(e.title, q));
        return { ok: true, message: t(loc, "deleted"), patch: { events: next } };
      }
      case "volume_set": {
        const percent = Math.max(0, Math.min(100, Number(args.percent ?? 0)));
        return { ok: true, message: t(loc, "volumeSet", { n: percent }), patch: { mediaVolume: percent / 100 } };
      }
      case "media_play":
        return { ok: true, message: t(loc, "success"), openUrl: "https://open.spotify.com" };
      case "media_pause":
        if (typeof window !== "undefined") window.speechSynthesis?.cancel();
        return { ok: true, message: t(loc, "success") };
      case "media_next":
      case "media_prev":
        return { ok: true, message: t(loc, "browserLimit") };
      case "flashlight":
        return {
          ok: true,
          message: args.on ? t(loc, "flashlightOn") : t(loc, "flashlightOff"),
          patch: { flashlightOn: Boolean(args.on) },
        };
      case "camera_open":
        return { ok: true, message: t(loc, "cameraOpened"), navigate: "/system?tab=camera", needsPermission: "camera" };
      case "file_search": {
        const q = String(args.query ?? "");
        const hits = state.files.filter((f) => includesNormalized(f.name, q) || !q);
        if (!hits.length) return { ok: true, message: t(loc, "emptyFiles"), navigate: "/files" };
        return { ok: true, message: hits.slice(0, 5).map((f) => f.name).join(", "), navigate: "/files" };
      }
      case "file_open":
        return { ok: true, message: t(loc, "success"), navigate: "/files" };
      case "file_delete":
        return { ok: false, message: t(loc, "confirmDelete") };
      case "gallery_recent":
      case "gallery_open":
        return { ok: true, message: t(loc, "success"), navigate: "/files?tab=gallery" };
      case "contact_search": {
        const q = String(args.query ?? "");
        const hits = state.contacts.filter((c) => includesNormalized(c.name, q));
        if (!hits.length) return { ok: true, message: t(loc, "emptyContacts"), navigate: "/contacts" };
        return { ok: true, message: hits.map((c) => c.name).join(", ") };
      }
      case "contact_add":
        return { ok: true, message: t(loc, "success"), navigate: "/contacts" };
      case "notification_list": {
        const filter = String(args.filter ?? "all");
        const rows =
          filter === "important" ? state.notifications.filter((n) => n.important) : state.notifications;
        if (!rows.length) return { ok: true, message: t(loc, "emptyNotifications") };
        return { ok: true, message: rows.slice(0, 5).map((n) => n.title).join("; "), navigate: "/notifications" };
      }
      case "diagnostics_report":
        return { ok: true, message: t(loc, "success"), navigate: "/diagnostics" };
      case "weather":
        if (!state.online) return { ok: false, message: t(loc, "noNetworkWeather") };
        return { ok: true, message: extras?.weatherSummary ?? t(loc, "success"), navigate: "/weather" };
      case "translate":
        if (!state.online) return { ok: false, message: t(loc, "noNetworkAi") };
        return { ok: true, message: extras?.translation ?? t(loc, "success") };
      case "calculate":
        return { ok: true, message: String(args.value ?? "") };
      case "memory_save": {
        const next = remember(state.memory, String(args.value ?? ""), (args.category as never) || "facts");
        return { ok: true, message: t(loc, "remembered"), patch: { memory: next } };
      }
      case "memory_forget": {
        const res = forget(state.memory, String(args.value ?? ""));
        return { ok: true, message: t(loc, "forgot"), patch: { memory: res.items } };
      }
      case "memory_list": {
        const rows = listMemory(state.memory);
        if (!rows.length) return { ok: true, message: t(loc, "emptyMemory"), navigate: "/memory" };
        return { ok: true, message: rows.slice(0, 8).map((m) => m.value).join("; "), navigate: "/memory" };
      }
      case "settings_open":
        return { ok: true, message: t(loc, "success"), navigate: "/settings" };
      case "focus_mode": {
        const on = Boolean(args.on);
        return { ok: true, message: on ? t(loc, "focusOn") : t(loc, "focusOff"), patch: { focusMode: on } };
      }
      case "history_query": {
        const q = String(args.query ?? "");
        const hits = state.history.filter((h) => includesNormalized(h.title, q) || includesNormalized(h.detail, q) || /yesterday|вчора/.test(q));
        if (!hits.length) return { ok: true, message: t(loc, "emptyHistory"), navigate: "/history" };
        return { ok: true, message: hits.slice(0, 5).map((h) => h.title).join("; "), navigate: "/history" };
      }
      case "ai_respond":
        return { ok: true, message: extras?.aiReply ?? t(loc, "success") };
      case "clipboard_copy":
        return { ok: true, message: t(loc, "copied") };
      case "ask_user":
        return { ok: true, message: String(args.question ?? "") };
      case "routine_run":
      case "automation_run":
      case "custom_command_run":
        return { ok: true, message: t(loc, "success") };
      case "none":
        return { ok: true, message: t(loc, "success") };
      default:
        return { ok: false, message: t(loc, "errorGeneric") };
    }
  } catch (err) {
    logger.error("TASK", "executor failed", { kind, error: String(err) });
    return { ok: false, message: t(loc, "errorGeneric") };
  }
}

export { notify };
